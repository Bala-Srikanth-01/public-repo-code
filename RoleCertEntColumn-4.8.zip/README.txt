RoleCertEntColumn 4.8
=====================

WHAT IT DOES

Adds a "Role Entitlements" column to the role composition access review
grid, listing each entitlement in the profile on its own line, with an
Approve / Revoke button beside each one.

When you then click IdentityIQ's own Revoke on the row and its comment
dialog opens, the plugin fills the comment box with a note naming the
individual entitlements, for example:

  Per-entitlement review: Remove: Dev-Access | Keep: read-access

Only entitlements the reviewer marked appear. Anything left untouched is
not mentioned either way.

That comment travels through sign-off into the work item raised for the
role owner, so the owner is told exactly which entitlement to take out.


WORK ITEMS ARE RAISED ONLY BY REVOCATION

Approving a row raises no work item, so nothing reaches the role owner
and the note goes nowhere. If anything in the profile needs to change,
the reviewer must REVOKE the row - the comment then says which
entitlements to remove and which to keep.

The plugin shows a reminder in the column as soon as an entitlement is
marked for removal, so this is hard to get wrong by accident.


NEW IN 4.8 - SAVED ROWS ARE READ-ONLY

When IdentityIQ has saved a row's decision (its Approve / Revoke buttons
are replaced by "Approved" / "Revoked"), the entitlement buttons are
removed from that row, so choices can no longer be changed after Save
Decisions or sign-off. If the decision is undone and the buttons return,
the row unlocks by itself (LOCK_SAVED_ROWS).

If the saved comment is visible anywhere in the row, each entitlement
also gets a small Remove / Keep tag from it. If IdentityIQ does not put
the comment in the row, the row shows the plain entitlement list; the
choices are still recorded in the decision comment and the work item.


NEW IN 4.7

While every entitlement on a row is marked Approve, the row's Revoke
button is greyed out and ignores clicks (BLOCK_REVOKE), so the comment
dialog cannot open for a fully approved row. It works again as soon as
any entitlement is switched to Revoke, on Clear, or if the row was
already revoked before (so that Revoke can still be undone).


NEW IN 4.6

When EVERY entitlement on a row is marked Approve, the row's own Approve
button gets a green outline and a short green line appears under it:
    All entitlements approved: approve this row
Nothing is clicked and Revoke is not blocked. The highlight goes away once
the row is approved, if any entitlement is switched to Revoke (the red
Revoke guidance takes over), or on Clear. Rows with one entitlement are
not affected. GUIDE_APPROVE_NOTE sets the line text ('' = no line).


NEW IN 4.5

A profile with only ONE entitlement shows the entitlement but no
Approve / Revoke buttons beside it. The row's own Approve / Revoke already
decides that single entitlement, so there is nothing extra to choose, no
note, no highlight and nothing added to the work item. Set
SINGLE_ENT_BUTTONS = true to bring the buttons back on those rows.

Work item: if one work item lists two or more profiles on the SAME
application, the note cannot say which profile it belongs to, so the
Entitlement Changes column says "See the reviewer comment above" on
those rows instead of guessing.


NEW IN 4.4

Work item page
  The role owner's work item gets an "Entitlement Changes" column in the
  Role Requests table, next to "Remove Profile":
      Remove  2207|6412|APP|1004|Underwriter
      Keep    2207|6412|APP|1086|Actuary
  It is read from the reviewer's note on that same work item, so it works
  for any number of roles. The note now includes the application name,
  e.g. "Per-entitlement review (GLMS [6412] clone): Remove: ...", so a work
  item with several profiles shows each note on the right row. Notes
  written by 4.3 (no application) still show when the item has one note.

Fixes - the plugin must not change stock behaviour
  - The note is only put into the dialog opened by the reviewer clicking
    that row's Revoke. Approve, Delegate and every other dialog are left
    empty, exactly as IdentityIQ draws them.
  - Only multi-line comment boxes are ever filled. 4.3 could fill a
    one-line text box, such as the identity search in the Delegate dialog,
    which then failed with a system error.
  - IdentityIQ's Clear (next to Save Decisions) now also clears every
    entitlement mark, filled button, Revoke highlight and guide line.


NEW IN 4.3 - GUIDE, DON'T CLICK

4.2 clicked the row's Revoke for the reviewer, which made IdentityIQ's
comment dialog pop up on every entitlement mark. 4.3 clicks nothing.

While any entitlement on a row is marked Revoke:
  - the row's own Revoke button gets a red outline (pulses twice),
  - the row's Approve button is greyed out and ignores clicks
    (BLOCK_APPROVE), since approving would send nothing to the owner,
  - a short line under the buttons says:
      Revoke required: 1 entitlement marked for removal

The reviewer clicks Revoke themselves. The dialog opens once, with the
per-entitlement note already in the comment box.

Set every mark back to Approve and all of it goes away: Approve works
again and the highlight and line disappear.

If the marks change after the row was revoked, the line reads
"Marks changed. Click Revoke again to update the comment."


THE WORK ITEM ITSELF

The description and "Remove Profile" operation are generated by
IdentityIQ at sign-off and are unchanged. The Entitlement Changes column
is added in the browser from the comment, so it appears on the work item
page but not in notification emails, and it reflects the comment as saved.


WHAT IT DOES NOT DO

The per-entitlement buttons do NOT record decisions. Only IdentityIQ
writes to its certification tables, and a UI plugin cannot. The row-level
Approve / Revoke is still the decision of record; the buttons only build
the wording of the comment.

Because the note is free text, it is guidance for the role owner, not
structured audit data. You cannot report on it.


BEFORE IT WILL WORK

The certification must be scheduled with "require comments" enabled for
revocation (and approval, if you want notes on approvals too). Without
that, IdentityIQ never opens a comment dialog and there is nothing to
fill.

The role itself is NOT modified. No profiles are split, so role detection
is unchanged - this is the difference from the rule-based approach.


SETTINGS

At the top of ui/js/snippets/entitlementsColumn.js:

  INSERT_BEFORE      which column to sit before        'decision'
  CONSTRAINTS_HEADER column parsed for entitlements    'constraints'
  COLUMN_TITLE       header text                       'Role Entitlements'
  ENT_BUTTONS        show per-entitlement buttons      true
  SINGLE_ENT_BUTTONS buttons when profile has only one false
  AUTOFILL_COMMENT   fill the comment dialog           true
  NOTE_PREFIX        text in front of the note
  WARNING_TEXT       reminder to revoke the row ('' = off)
  GUIDE_ROW_DECISION highlight row Revoke on marks    true
  BLOCK_APPROVE      grey out row Approve on marks     true
  BLOCK_REVOKE       grey out row Revoke if all Approve true
  LOCK_SAVED_ROWS    read-only once decision is saved  true
  GUIDE_NOTE_ONE/MANY line under the decision buttons
  STALE_NOTE         shown if marks change after revoke
  APPLICATION_HEADER column with the application name 'application'
  WORKITEM_COLUMN    add column on work item page      true
  DECISION_HEADER    column with the row buttons       'decision'
  PRESSED_CLASS      classes that mean selected
  MARK_MODE          tick boxes + Copy note button     false
  SKIP_SINGLE        blank the column on split roles   false
  VISIBLE_LINES      lines before "Show more"          3


IF THE COMMENT BOX IS NOT FILLED

Open the browser console on the access review page:

  rceCol.note()    the note for the row last clicked
  rceCol.field()   the comment field it would fill, or null
  rceCol.fill()    force an attempt
  rceCol.decision() whether the plugin sees the row as revoked, plus the
                   HTML of the row's Approve / Revoke buttons
  rceCol.state()    marks remembered per row

If note() is null, no entitlement was marked on that row. If field() is
null, the dialog's box was not recognised - send the dialog's HTML and
the selector can be narrowed.


INSTALL

Global Settings - Plugins - upload the zip. Refresh the access review
page afterwards.
