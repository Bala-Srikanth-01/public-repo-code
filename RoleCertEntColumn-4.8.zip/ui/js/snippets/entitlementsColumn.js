/*
 * RoleCertEntColumn v4.8
 *
 * ONE JOB: add a "Role Entitlements" column to the role composition
 * access review grid, with each entitlement on its own line.
 *
 * It does NOT touch anything else on the page. Checkboxes, Bulk
 * Decisions, the "Role: X" group rows, Approve/Revoke, paging - all
 * stock IdentityIQ, left exactly as they are.
 *
 * WHERE THE DATA COMES FROM
 * -------------------------
 * The row already carries it. A role composition access review shows the
 * entitlement profile in the Constraints column, as one dense line:
 *
 *   EntitlementValue Contains All Of [Administrators + PWCHFSSGFTP01,
 *   Administrators + pwgsdscs3308001, Domain Users + pwchfssgclp01]
 *
 * We parse that and print:
 *
 *   Administrators + PWCHFSSGFTP01
 *   Administrators + pwgsdscs3308001
 *   Domain Users + pwchfssgclp01
 *
 * Real data. No Java, no jar, no REST endpoint, no database.
 *
 * WHY THE SWEEP RUNS REPEATEDLY
 * -----------------------------
 * The grid repaints its rows on sort / page / filter. Rather than inject
 * once and hope, every pass enforces exactly ONE header cell and ONE cell
 * per row at the same column index, removing any extras. Running it twice
 * changes nothing, so repaints are harmless. This is what stops the
 * duplicate cells and mismatched fonts seen in earlier versions.
 */
(function (window, document) {
    'use strict';

    /* ------------------------------ CONFIG ------------------------------ */

    /* Column header text to insert BEFORE, so the new column is visible
       without scrolling past the wide Decision column. Case insensitive.
       Set to '' to append the column last instead. */
    var INSERT_BEFORE = 'decision';

    /* Column header holding the constraint string we parse. */
    var CONSTRAINTS_HEADER = 'constraints';

    /* Column holding the application name. It is written into the note so
       a work item covering several profiles can match each note to the
       right profile. */
    var APPLICATION_HEADER = 'application';

    /* Work item page: add an "Entitlement Changes" column to the Role
       Requests table, built from the reviewer's per-entitlement note.
       Set false to leave the work item page untouched. */
    var WORKITEM_COLUMN = true;
    var WORKITEM_COLUMN_TITLE = 'Entitlement Changes';

    /* Our column's header text. */
    var COLUMN_TITLE = 'Role Entitlements';

    /* Show a tick box beside each entitlement so a reviewer can mark which
       ones they think should come out of the profile, then copy that as a
       note to paste into the stock Comments box. The tick itself records
       NOTHING in IdentityIQ - the stock Approve/Revoke decision and the
       comment are what get saved. Set false for a display-only column. */
    var MARK_MODE = false;

    /* A role whose profiles have been split already shows ONE entitlement
       per row, and the Constraints column right next to us says the same
       thing. Repeating it adds noise, so those rows are left blank.
       Set false to always fill the column. */
    var SKIP_SINGLE = false;

    /* Approve / Revoke buttons beside each entitlement. These do NOT write
       a decision - only IdentityIQ's own row buttons do that. What they do
       is build the note that goes into the stock Comments box, so the role
       owner is told exactly which entitlement to take out. */
    var ENT_BUTTONS = true;

    /* A profile with ONE entitlement needs no per-entitlement choice: the
       row's own Approve / Revoke already decides that entitlement. So the
       buttons are shown only when a profile has two or more. Set true to
       show them on single-entitlement rows too. */
    var SINGLE_ENT_BUTTONS = false;

    /* When IdentityIQ opens its comment dialog after Revoke, put the note
       for that row into the comment box automatically. The reviewer can
       still edit or clear it before saving. Set false to leave the box
       empty and use the Copy note button instead. */
    var AUTOFILL_COMMENT = true;

    /* Text put in front of the note, so the role owner sees at a glance
       that it lists individual entitlements. '' for no prefix. */
    var NOTE_PREFIX = 'Per-entitlement review: ';

    /* Shown under the entitlements once one is marked for removal.
       Set to '' to switch the warning off. */
    var WARNING_TEXT = 'Revoke the row to send this to the role owner. '
                     + 'Approving the row raises no work item.';

    /* ---- 4.3: guide the reviewer to the row decision ----

       GUIDE_ROW_DECISION
         While any entitlement on a row is marked Revoke, the row's own
         IdentityIQ Revoke button is highlighted and a short line under it
         says why. Nothing is clicked for the reviewer, so the comment
         dialog only opens when THEY click Revoke.
         Set every mark back to Approve and the highlight goes away.
       Set false for 4.1 behaviour (amber warning in the column only). */
    var GUIDE_ROW_DECISION = true;

    /* While entitlements are marked for removal, the row's Approve button
       is greyed out and ignores clicks, because approving would send
       nothing to the role owner. Set false to leave Approve clickable. */
    var BLOCK_APPROVE = true;

    /* While EVERY entitlement is marked Approve, the row's Revoke button
       is greyed out and ignores clicks, so the comment dialog cannot open
       for a row the reviewer has fully approved. Set false to leave
       Revoke clickable. */
    var BLOCK_REVOKE = true;

    /* Once IdentityIQ has saved a row's decision (its Approve / Revoke
       buttons are replaced by "Approved" / "Revoked"), the entitlement
       buttons are removed and the row becomes read-only. It unlocks by
       itself if the decision is undone and the buttons come back. */
    var LOCK_SAVED_ROWS = true;

    /* Line under the row's decision buttons. {n} = number marked. */
    var GUIDE_NOTE_ONE  = 'Revoke required: 1 entitlement marked for removal';
    var GUIDE_NOTE_MANY = 'Revoke required: {n} entitlements marked for removal';

    /* Shown on a revoked row when the marks changed after its comment was
       filled, so the saved comment no longer matches. */
    /* When EVERY entitlement on a row is marked Approve, the row's own
       Approve button is highlighted green, with this line under it.
       Nothing is clicked or blocked. '' = highlight without the line. */
    var GUIDE_APPROVE_NOTE = 'All entitlements approved: approve this row';

    var STALE_NOTE = 'Marks changed. Click Revoke again to update the comment.';

    /* Column holding IdentityIQ's own Approve / Revoke buttons. */
    var DECISION_HEADER = 'decision';

    /* How the plugin recognises which stock row button is selected.
       IdentityIQ skins differ; if rceCol.decision() in the console reports
       'unknown' on a decided row, add the selected button's class here. */
    var PRESSED_CLASS = /(^|\s)(active|selected|pressed|checked|btn-success|btn-danger|is-selected)(\s|$)/i;

    /* Entitlement lines shown before "Show more". Set to 0 for no limit. */
    var VISIBLE_LINES = 3;

    /* Safety-net re-check interval, ms. The MutationObserver catches
       repaints much faster; this only covers anything it misses. */
    var SWEEP_MS = 1500;

    /* --------------------------------------------------------------------- */

    var COL = 'rce-col';

    function toArray(nl) { return Array.prototype.slice.call(nl); }

    /* ---------------------------- find the grid -------------------------- */

    /* The certification grid is the largest table on the page that has a
       thead and is not nested inside another cell. Deliberately structural
       rather than class-based: IIQ grid class names differ across versions
       and skins, and a wrong class name would mean no column at all. */
    function findGrid() {
        var best = null, bestRows = 0;
        toArray(document.querySelectorAll('table')).forEach(function (t) {
            if (!t.tHead || !t.tBodies.length) { return; }
            if (t.parentNode && t.parentNode.closest &&
                t.parentNode.closest('td, th')) { return; }
            var n = t.tBodies[0].rows.length;
            if (n > bestRows) { best = t; bestRows = n; }
        });
        return best;
    }

    function headerRow(grid) {
        return (grid.tHead && grid.tHead.rows.length)
            ? grid.tHead.rows[grid.tHead.rows.length - 1]
            : null;
    }

    /* Position of the header cell whose text starts with `title`,
     * expressed as THE NUMBER OF STOCK CELLS BEFORE IT - not as a raw
     * cellIndex. This matters: once our own cell is in the row, a raw
     * index counts it too, and every sweep would shift the column one
     * place further along. Counting only stock cells is stable.
     * Returns -1 if not found. */
    function headerIndex(hr, title) {
        if (!title) { return -1; }
        var want = title.toLowerCase(), n = 0;
        for (var i = 0; i < hr.cells.length; i++) {
            var c = hr.cells[i];
            if (c.classList.contains(COL)) { continue; }
            var t = (c.textContent || '').trim().toLowerCase();
            if (t === want || t.indexOf(want) === 0) { return n; }
            n++;
        }
        return -1;
    }

    /* The nth stock cell of a row (ignoring our own cell). */
    function stockCellAt(row, n) {
        var seen = 0;
        for (var i = 0; i < row.cells.length; i++) {
            var c = row.cells[i];
            if (c.classList.contains(COL)) { continue; }
            if (seen === n) { return c; }
            seen++;
        }
        return null;
    }

    /* Total stock cells in a row. */
    function stockCount(row) {
        var n = 0;
        for (var i = 0; i < row.cells.length; i++) {
            if (!row.cells[i].classList.contains(COL)) { n++; }
        }
        return n;
    }

    /* Rows belonging to this grid only, never rows of a nested table. */
    function ownRows(grid) {
        var rows = [];
        toArray(grid.tBodies).forEach(function (tb) {
            if (tb.parentNode !== grid) { return; }
            toArray(tb.rows).forEach(function (tr) {
                if (tr.closest('table') === grid) { rows.push(tr); }
            });
        });
        return rows;
    }

    /* ------------------------ placement ---------------------------------
     * Numeric cellIndex arithmetic drifts as soon as our own cell is in
     * the row, or a row has a different number of cells from the header.
     * When it drifts, a stock cell ends up under our header - which is
     * exactly the "raw Constraints text under Role Entitlements" symptom.
     *
     * Instead we mirror an anchor: our cell always goes before the Nth
     * STOCK cell (ignoring our own), where N is the same number used in
     * the header. Counting only stock cells makes this stable no matter
     * how often the sweep runs.
     * ------------------------------------------------------------------ */

    /* Number of stock cells that precede our cell in the header. */
    function stockCellsBefore(row, node) {
        var n = 0;
        for (var i = 0; i < row.cells.length; i++) {
            if (row.cells[i] === node) { return n; }
            if (!row.cells[i].classList.contains(COL)) { n++; }
        }
        return n;
    }

    /* Insert `node` into `row` so that exactly `n` stock cells precede it. */
    function placeMirrored(row, node, n) {
        var seen = 0, ref = null;
        for (var i = 0; i < row.cells.length; i++) {
            var c = row.cells[i];
            if (c === node) { continue; }
            if (seen === n) { ref = c; break; }
            if (!c.classList.contains(COL)) { seen++; }
        }
        if (node.parentNode === row && node.nextElementSibling === ref) {
            return;                       /* already in the right place */
        }
        row.insertBefore(node, ref);
    }

    /* The row's constraint text. Uses the header index, but falls back to
       scanning the row when that cell holds nothing bracket-like - so a
       row with an unexpected shape still renders instead of showing raw
       text or nothing. */
    function constraintText(tr, cIdx) {
        var cell = (cIdx > -1) ? stockCellAt(tr, cIdx) : null;
        if (cell) {
            var t = cell.textContent || '';
            if (t.indexOf('[') > -1) { return t; }
        }
        /* fallback: a row with an unexpected shape still renders */
        for (var i = 0; i < tr.cells.length; i++) {
            var c = tr.cells[i];
            if (c.classList.contains(COL)) { continue; }
            var s2 = c.textContent || '';
            if (s2.indexOf('[') > -1 && /contains|equals|\+/i.test(s2)) {
                return s2;
            }
        }
        return cell ? (cell.textContent || '') : '';
    }

    /* A "Role: X" group header row spans the grid. It gets no cell of its
       own - adding one would push the real columns out of alignment.
       It is otherwise left completely alone. */
    function isGroupRow(tr) {
        for (var i = 0; i < tr.cells.length; i++) {
            if (tr.cells[i].colSpan > 1) { return true; }
        }
        return false;
    }

    /* ---------------------------- parse ---------------------------------- */

    /* Pull the entitlements out of a constraint string.
     *
     * Two real formats, both from live role composition reviews:
     *
     *   Contains All Of [AcctsPayableAccess, AcctsPayableAccess1,
     *                    AcctsReceivableAccess]
     *     -> three separate entitlements, split on commas.
     *
     *   Group Membership Contains All Of [CN=Dev Group Admin,OU=DEV
     *                    USERS,DC=seri,DC=sailpointdemo,DC=com]
     *     -> ONE entitlement: an LDAP distinguished name that happens to
     *        contain commas. Splitting it would produce four meaningless
     *        fragments, so DN components are kept together.
     *
     * The rule: split on commas, then re-join any piece that begins with
     * an LDAP attribute prefix (CN=, OU=, DC=, O=, UID=, ...) onto the
     * previous piece, since it is a continuation of the same DN.
     *
     * If there are no brackets the whole string is shown as one line
     * rather than nothing, so no data is ever silently dropped.
     */
    var DN_PART = /^(cn|ou|dc|o|l|st|c|uid|dn|sn|email|mail)\s*=/i;

    function splitList(inner) {
        var parts = inner.split(','), out = [];
        parts.forEach(function (raw) {
            var v = raw.trim();
            if (!v) { return; }
            if (out.length && DN_PART.test(v) && DN_PART.test(out[out.length - 1])) {
                out[out.length - 1] += ',' + v;   /* same DN, keep together */
            } else {
                out.push(v);
            }
        });
        return out;
    }

    function parseConstraints(text) {
        if (!text) { return []; }
        var out = [], re = /\[([^\]]*)\]/g, m;
        while ((m = re.exec(text)) !== null) {
            splitList(m[1].replace(/\s+/g, ' ')).forEach(function (v) {
                out.push(v);
            });
        }
        if (!out.length) {
            var t = text.replace(/\s+/g, ' ').trim();
            if (t) { out.push(t); }
        }
        return out;
    }

    /* ---------------------------- row state ------------------------------
     * The grid repaints rows on sort / page / filter and when a decision is
     * made, which throws away our cell and anything drawn in it. Choices
     * are therefore kept here, keyed by role + constraint text, and drawn
     * back onto whatever row currently shows that profile.
     * --------------------------------------------------------------------- */

    var rowState = {};

    function stateFor(key) {
        if (!rowState[key]) {
            rowState[key] = { choices: {}, savedNote: null };
        }
        return rowState[key];
    }

    /* Role name from the nearest "Role: X" group row above. */
    function roleOf(tr) {
        var p = tr.previousElementSibling;
        while (p) {
            if (isGroupRow(p)) {
                return (p.textContent || '').replace(/\s+/g, ' ').trim();
            }
            p = p.previousElementSibling;
        }
        return '';
    }

    function keyOf(tr, text) {
        return roleOf(tr) + '||' + (text || '').replace(/\s+/g, ' ').trim();
    }

    function removalCount(st) {
        var n = 0;
        Object.keys(st.choices).forEach(function (k) {
            if (st.choices[k] === 'revoke') { n++; }
        });
        return n;
    }

    /* ---------------------------- render --------------------------------- */

    function buildHeaderCell() {
        var th = document.createElement('th');
        th.className = COL;
        th.textContent = COLUMN_TITLE;
        return th;
    }

    function renderCell(td, ents, st, locked, saved) {
        while (td.firstChild) { td.removeChild(td.firstChild); }
        if (!ents.length) { return; }          /* blank cell, no filler text */

        /* Already-split row: one entitlement, already readable in
           Constraints. Nothing useful to add, so add nothing. */
        if (SKIP_SINGLE && ents.length === 1) { return; }

        var limit = (VISIBLE_LINES > 0) ? VISIBLE_LINES : ents.length;
        var showButtons = ENT_BUTTONS && !locked && (ents.length > 1 || SINGLE_ENT_BUTTONS);

        /* marks left over from a time this row had more entitlements are
           dropped, so no hidden choice can block Approve */
        if (st && !showButtons) { st.choices = {}; }

        var wrap = document.createElement('div');
        wrap.className = 'rce-lines';
        ents.forEach(function (e, i) {
            var line = document.createElement('div');
            line.className = 'rce-line' + (i >= limit ? ' rce-hide' : '');

            if (MARK_MODE) {
                var box = document.createElement('input');
                box.type = 'checkbox';
                box.className = 'rce-mark';
                box.setAttribute('aria-label', 'Mark for removal: ' + e);
                line.appendChild(box);
            }

            var txt = document.createElement('span');
            txt.className = 'rce-text';
            txt.textContent = e;
            line.appendChild(txt);

            if (showButtons) {
                line.appendChild(buildEntButtons(e));
            } else if (locked && saved) {
                /* read-only: show what the saved comment says */
                var choice = saved.remove.indexOf(e) > -1 ? 'revoke'
                    : (saved.keep.indexOf(e) > -1 ? 'approve' : null);
                if (choice) {
                    var tag = document.createElement('span');
                    tag.className = 'rce-lock-tag rce-lock-' + choice;
                    tag.textContent = choice === 'revoke' ? 'Remove' : 'Keep';
                    line.appendChild(tag);
                    line.classList.add('rce-chose-' + choice);
                }
            }

            wrap.appendChild(line);
            if (st && showButtons) { paintChoice(line, st.choices[e] || null); }
        });
        td.appendChild(wrap);

        if (ents.length > limit) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'rce-toggle';
            btn.textContent = 'Show ' + (ents.length - limit) + ' more';
            td.appendChild(btn);
        }

        if (MARK_MODE) {
            var foot = document.createElement('div');
            foot.className = 'rce-foot';

            var note = document.createElement('button');
            note.type = 'button';
            note.className = 'rce-note';
            note.textContent = 'Copy note';
            foot.appendChild(note);

            var hint = document.createElement('span');
            hint.className = 'rce-hint';
            hint.textContent = 'ticks build a note, not a decision';
            foot.appendChild(hint);

            td.appendChild(foot);
            updateFoot(td);
        }

        if (WARNING_TEXT) { updateWarning(td); }
    }

    /* Colour the entitlement AND fill the button that was pressed, so the
       reviewer can see which one is selected, not only the text colour. */
    function paintChoice(line, choice) {
        line.classList.remove('rce-chose-approve', 'rce-chose-revoke');
        if (choice) { line.classList.add('rce-chose-' + choice); }
        toArray(line.querySelectorAll('.rce-act')).forEach(function (b) {
            var mine = b.classList.contains('rce-act-' + choice);
            b.classList.toggle('rce-act-on', !!choice && mine);
            b.setAttribute('aria-pressed', (!!choice && mine) ? 'true' : 'false');
        });
    }

    /* Show the footer only once something is marked. */
    function updateFoot(td) {
        var foot = td.querySelector('.rce-foot');
        if (!foot) { return; }
        var marked = td.querySelectorAll('.rce-mark:checked').length;
        foot.style.display = marked ? '' : 'none';
        var btn = foot.querySelector('.rce-note');
        if (btn && btn.getAttribute('data-copied') !== '1') {
            btn.textContent = 'Copy note (' + marked + ')';
        }
    }

    /* Build the note for one row. Only entitlements the reviewer actually
       marked are listed, so nothing untouched is reported either way. */
    function noteTextFor(td) {
        var remove = [], keep = [];

        toArray(td.querySelectorAll('.rce-line')).forEach(function (line) {
            var txt = line.querySelector('.rce-text');
            if (!txt) { return; }
            var name = txt.textContent;
            var box = line.querySelector('.rce-mark');

            if (line.classList.contains('rce-chose-revoke')
                || (box && box.checked)) {
                remove.push(name);
            } else if (line.classList.contains('rce-chose-approve')) {
                keep.push(name);
            }
        });

        if (!remove.length && !keep.length) { return ''; }

        var parts = [];
        if (remove.length) { parts.push('Remove: ' + remove.join('; ')); }
        if (keep.length) { parts.push('Keep: ' + keep.join('; ')); }

        var app = applicationOf(td);
        var prefix = app
            ? NOTE_PREFIX.replace(/:\s*$/, '') + ' (' + app + '): '
            : NOTE_PREFIX;
        return prefix + parts.join(' | ');
    }

    function applicationOf(td) {
        var tr = td.closest('tr');
        var grid = tr && tr.closest('table');
        var hr = grid && headerRow(grid);
        var idx = hr ? headerIndex(hr, APPLICATION_HEADER) : -1;
        var cell = idx > -1 ? stockCellAt(tr, idx) : null;
        return cell ? (cell.textContent || '').replace(/\s+/g, ' ').trim() : '';
    }

    /* True when at least one entitlement on this row is marked for removal. */
    function hasRemoval(td) {
        return !!(td.querySelector('.rce-chose-revoke')
               || td.querySelector('.rce-mark:checked'));
    }

    /* With GUIDE_ROW_DECISION on, the hint sits next to the row's own
       buttons instead, so the amber box in the column is not repeated. */
    function updateWarning(td) {
        var warn = td.querySelector('.rce-warn');
        var handled = GUIDE_ROW_DECISION;

        if (!hasRemoval(td) || handled) {
            if (warn) { warn.parentNode.removeChild(warn); }
            return;
        }
        if (warn) { return; }

        warn = document.createElement('div');
        warn.className = 'rce-warn';
        warn.textContent = WARNING_TEXT;
        td.appendChild(warn);
    }

    function onCopyNote(btn) {
        var td = btn.closest('td.' + COL);
        if (!td) { return; }
        var text = noteTextFor(td);
        var done = function () {
            btn.setAttribute('data-copied', '1');
            btn.textContent = 'Copied - paste into Comments';
            setTimeout(function () {
                btn.removeAttribute('data-copied');
                updateFoot(td);
            }, 4000);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(done, function () {
                fallbackCopy(text, done);
            });
        } else {
            fallbackCopy(text, done);
        }
    }

    function fallbackCopy(text, done) {
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand('copy'); } catch (e) { /* ignore */ }
        document.body.removeChild(ta);
        done();
    }

    /* Approve / Revoke pair for one entitlement line. */
    function buildEntButtons(name) {
        var box = document.createElement('span');
        box.className = 'rce-acts';

        ['Approve', 'Revoke'].forEach(function (label) {
            var b = document.createElement('button');
            b.type = 'button';
            b.className = 'rce-act rce-act-' + label.toLowerCase();
            b.textContent = label;
            b.setAttribute('aria-pressed', 'false');
            b.setAttribute('aria-label', label + ' ' + name);
            b.title = 'Marks this entitlement in the comment sent to the role owner.';
            box.appendChild(b);
        });

        return box;
    }

    function onEntAct(btn) {
        var line = btn.closest('.rce-line');
        var td = btn.closest('td.' + COL);
        if (!line || !td) { return; }

        var chose = btn.classList.contains('rce-act-approve') ? 'approve' : 'revoke';
        var name = line.querySelector('.rce-text').textContent;
        var key = td.getAttribute('data-key');
        var st = stateFor(key);

        st.choices[name] = chose;
        paintChoice(line, chose);

        if (WARNING_TEXT) { updateWarning(td); }
        if (GUIDE_ROW_DECISION) { guideRow(key); }
    }

    function onToggle(btn) {
        var wrap = btn.parentNode.querySelector('.rce-lines');
        if (!wrap) { return; }
        var expand = !!wrap.querySelector('.rce-hide');
        var limit = (VISIBLE_LINES > 0) ? VISIBLE_LINES : wrap.children.length;
        toArray(wrap.children).forEach(function (line, i) {
            line.classList.toggle('rce-hide', !expand && i >= limit);
        });
        btn.textContent = expand
            ? 'Show less'
            : 'Show ' + (wrap.children.length - limit) + ' more';
    }

    /* ------------------ the row's own IdentityIQ decision ------------------ */

    function rowFor(key) {
        var td = document.querySelector('td.' + COL + '[data-key="' + cssEscape(key) + '"]');
        return td ? td.closest('tr') : null;
    }

    function cssEscape(s) {
        return String(s).replace(/(["\\])/g, '\\$1');
    }

    function decisionCell(tr) {
        var grid = tr.closest('table');
        var hr = grid && headerRow(grid);
        var idx = hr ? headerIndex(hr, DECISION_HEADER) : -1;
        return idx > -1 ? stockCellAt(tr, idx) : null;
    }

    /* The stock Approve or Revoke button in a row. Our own buttons and
       anything inside our column are never matched. */
    function nativeButton(tr, label) {
        var cell = decisionCell(tr);
        var scope = cell || tr;
        var want = label.toLowerCase();
        var list = toArray(scope.querySelectorAll('button, a[role="button"], [role="button"]'));
        for (var i = 0; i < list.length; i++) {
            var b = list[i];
            if (b.closest('.' + COL) || b.classList.contains('rce-act')) { continue; }
            var t = (b.textContent || b.getAttribute('aria-label') || '')
                .replace(/\s+/g, ' ').trim().toLowerCase();
            if (t === want || t.indexOf(want) === 0) { return b; }
        }
        return null;
    }

    function looksPressed(b) {
        if (!b) { return false; }
        if (b.getAttribute('aria-pressed') === 'true') { return true; }
        if (b.getAttribute('aria-checked') === 'true') { return true; }
        return PRESSED_CLASS.test(b.className || '');
    }

    function rowRevoked(tr) {
        return looksPressed(nativeButton(tr, 'Revoke'));
    }

    function noteFor(key) {
        var tr = rowFor(key);
        var td = tr && tr.querySelector('td.' + COL);
        return td ? noteTextFor(td) : '';
    }

    /* Draw or clear the guidance for one row. Nothing is clicked: the
       Revoke button is only highlighted, Approve is greyed out, and one
       short line explains why. */
    function guideRow(key) {
        var tr = rowFor(key);
        if (!tr) { return; }
        var st = rowState[key];
        var n = st ? removalCount(st) : 0;
        var revoke = nativeButton(tr, 'Revoke');
        var approve = nativeButton(tr, 'Approve');
        var revoked = rowRevoked(tr);
        var approved = looksPressed(approve);

        /* all entitlements that have buttons are marked Approve */
        var td = tr.querySelector('td.' + COL);
        var lines = td ? toArray(td.querySelectorAll('.rce-line')).filter(function (l) {
            return !!l.querySelector('.rce-act');
        }) : [];
        var allApproved = lines.length > 0 && lines.every(function (l) {
            return l.classList.contains('rce-chose-approve');
        });
        var needApprove = allApproved && !approved;

        if (approve) {
            approve.classList.toggle('rce-need-approve', needApprove);
        }
        /* never block a Revoke that is already selected: the reviewer
           must still be able to undo it */
        setBlocked(revoke, BLOCK_REVOKE && allApproved && !revoked,
            'All entitlements are marked Approve. Approve this row.');

        if (revoke) {
            revoke.classList.toggle('rce-need-revoke', n > 0 && !revoked);
        }
        if (approve) {
            setBlocked(approve, BLOCK_APPROVE && n > 0,
                'Entitlements are marked for removal. Revoke this row.');
        }

        var text = '';
        if (needApprove && GUIDE_APPROVE_NOTE) {
            text = GUIDE_APPROVE_NOTE;
        } else if (n > 0 && !revoked) {
            text = (n === 1 ? GUIDE_NOTE_ONE : GUIDE_NOTE_MANY).replace('{n}', n);
        } else if (n > 0 && revoked && st.savedNote && st.savedNote !== noteFor(key)) {
            text = STALE_NOTE;
        }

        var cell = decisionCell(tr);
        if (!cell) { return; }
        var existing = cell.querySelector('.rce-auto-note');
        if (!text) {
            if (existing) { existing.parentNode.removeChild(existing); }
            return;
        }
        if (!existing) {
            existing = document.createElement('div');
            existing.className = 'rce-auto-note';
            existing.setAttribute('role', 'status');
            cell.appendChild(existing);
        }
        if (existing.textContent !== text) { existing.textContent = text; }
        existing.classList.toggle('rce-auto-note-approve', needApprove);
    }

    /* Approve ignores clicks while removals are marked. Capture phase on
       the document runs before IdentityIQ's own handler on the button. */
    /* Grey out a stock button, or restore it exactly as it was. */
    function setBlocked(b, block, why) {
        if (!b) { return; }
        var is = b.classList.contains('rce-blocked');
        if (block && !is) {
            b.classList.add('rce-blocked');
            b.setAttribute('aria-disabled', 'true');
            b.setAttribute('data-rce-title', b.title || '');
            b.title = why;
        } else if (!block && is) {
            b.classList.remove('rce-blocked');
            b.removeAttribute('aria-disabled');
            b.title = b.getAttribute('data-rce-title') || '';
            b.removeAttribute('data-rce-title');
        }
    }

    /* A greyed-out button ignores the click. Capture phase on the document
       runs before IdentityIQ's own handler. Returns true when blocked. */
    function blockDecision(e) {
        if (!GUIDE_ROW_DECISION) { return false; }
        if (!e.target || !e.target.closest) { return false; }
        if (!e.target.closest('.rce-blocked')) { return false; }
        e.preventDefault();
        e.stopPropagation();
        if (e.stopImmediatePropagation) { e.stopImmediatePropagation(); }
        return true;
    }

    /* ------------------- filling the stock comment box -------------------- */

    var lastCell = null;

    function rememberRow(target) {
        if (!target || !target.closest) { return; }
        var tr = target.closest('tr');
        if (!tr) { return; }
        var td = tr.querySelector('td.' + COL);
        if (td) { lastCell = td; }
    }

    function setFieldValue(field, text) {
        field.value = text;
        ['input', 'change', 'keyup', 'blur'].forEach(function (name) {
            var ev;
            try {
                ev = new Event(name, { bubbles: true });
            } catch (e) {
                ev = document.createEvent('Event');
                ev.initEvent(name, true, true);
            }
            field.dispatchEvent(ev);
        });
    }

    function visible(el) {
        return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
    }

    function findCommentField() {
        /* textarea only: a one-line text input in a dialog is usually a
           search box (e.g. Delegate's identity picker), and filling it
           breaks that dialog */
        var fields = toArray(document.querySelectorAll('textarea'));
        for (var i = 0; i < fields.length; i++) {
            var f = fields[i];
            if (f.closest('td.' + COL)) { continue; }
            if (f.closest('table')) { continue; }        /* not a grid filter */
            if (f.getAttribute('data-rce-filled') === '1') { continue; }
            if (!visible(f)) { continue; }
            if ((f.value || '').trim().length) { continue; }
            if (f.readOnly || f.disabled) { continue; }
            return f;
        }
        return null;
    }

    /* The note is only ever put into the dialog that the reviewer's own
       click on a row's Revoke button opened. Approve, Delegate, bulk
       actions and every other dialog are left exactly as IdentityIQ
       draws them. */
    var armed = null;

    function armFromClick(target) {
        if (!target || !target.closest) { return; }
        if (target.closest('.' + COL)) { return; }        /* our own buttons */
        var b = target.closest('button, a, [role="button"], [role="menuitem"], li');
        if (!b) { return; }
        var label = (b.textContent || b.getAttribute('aria-label') || '')
            .replace(/\s+/g, ' ').trim().toLowerCase();
        var tr = b.closest('tr');
        var td = tr && tr.querySelector('td.' + COL);
        var isRowRevoke = td && label.indexOf('revoke') === 0
            && decisionCell(tr) && decisionCell(tr).contains(b);
        if (isRowRevoke) {
            /* the note is taken now: IdentityIQ repaints the row as the
               dialog opens, and the new row has no column for a moment */
            armed = { key: td.getAttribute('data-key'), note: noteTextFor(td), at: Date.now() };
            return;
        }
        /* any other button or menu choice disarms, unless it is a click
           inside the dialog the Revoke opened */
        if (armed && !b.closest('[role="dialog"], .modal, .modal-dialog, .x-window')) {
            armed = null;
        }
    }

    function tryAutofill() {
        if (!AUTOFILL_COMMENT || !armed) { return; }
        if (Date.now() - armed.at > 15000) { armed = null; return; }
        var text = armed.note;
        if (!text) { return; }
        var field = findCommentField();
        if (!field) { return; }
        field.setAttribute('data-rce-filled', '1');
        setFieldValue(field, text);

        if (armed.key) { stateFor(armed.key).savedNote = text; }
        armed = null;                        /* one dialog, one fill */
    }

    /* ------------------------ IdentityIQ "Clear" ------------------------- */

    /* After a decision, IdentityIQ shows Save Decisions and Clear. Clear
       throws away unsaved decisions, so the entitlement marks, the filled
       buttons, the highlight and the guide line go too. Only a "Clear"
       that sits next to a "Save" button counts, so a search box's Clear
       does nothing. */
    function isDecisionClear(target) {
        if (!target || !target.closest) { return false; }
        if (target.closest('.' + COL)) { return false; }
        var b = target.closest('button, a, [role="button"]');
        if (!b) { return false; }
        var t = (b.textContent || b.value || '').replace(/\s+/g, ' ').trim().toLowerCase();
        if (t !== 'clear' && t !== 'clear decisions') { return false; }
        var box = b.parentNode;
        for (var up = 0; box && up < 3; up++, box = box.parentNode) {
            /* stop before reaching a container that also holds the grid
               or a search box: too broad to be the decision bar */
            if (box.querySelector && box.querySelector('table, input[type="text"], input[type="search"]')) {
                return false;
            }
            var found = toArray(box.querySelectorAll('button, a, [role="button"]')).some(function (x) {
                return x !== b && /^save/i.test((x.textContent || x.value || '').trim());
            });
            if (found) { return true; }
        }
        return false;
    }

    function clearAllMarks() {
        Object.keys(rowState).forEach(function (k) { delete rowState[k]; });
        armed = null;
        toArray(document.querySelectorAll('td.' + COL)).forEach(function (td) {
            td.removeAttribute('data-src');          /* forces a clean redraw */
        });
        toArray(document.querySelectorAll('.rce-need-revoke, .rce-need-approve')).forEach(function (b) {
            b.classList.remove('rce-need-revoke', 'rce-need-approve');
        });
        toArray(document.querySelectorAll('.rce-blocked')).forEach(function (b) {
            b.classList.remove('rce-blocked');
            b.removeAttribute('aria-disabled');
            b.title = b.getAttribute('data-rce-title') || '';
            b.removeAttribute('data-rce-title');
        });
        toArray(document.querySelectorAll('.rce-auto-note')).forEach(function (n) {
            n.parentNode.removeChild(n);
        });
        sweep();
    }

    /* --------------------------- work item page --------------------------
     * The role owner's work item lists "Remove Profile" rows but nothing
     * about individual entitlements. The reviewer's note is on the same
     * page, in the comments. Each work item reads its own note, so this
     * works the same for 1 role or 500.
     * ------------------------------------------------------------------- */

    var NOTE_RE = null;

    function noteRegex() {
        if (NOTE_RE) { return NOTE_RE; }
        var base = NOTE_PREFIX.replace(/:\s*$/, '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        NOTE_RE = new RegExp('^' + base + '(?:\\s*\\((.*?)\\))?:\\s*(.*)$', 'i');
        return NOTE_RE;
    }

    /* "... (GLMS [6412] clone): Remove: a; b | Keep: c"
       -> { app, remove: [a, b], keep: [c] } */
    function parseNote(text) {
        var m = noteRegex().exec((text || '').replace(/\s+/g, ' ').trim());
        if (!m) { return null; }
        var out = { app: (m[1] || '').trim(), remove: [], keep: [] };
        m[2].split(' | ').forEach(function (part) {
            var mm = /^(remove|keep):\s*(.*)$/i.exec(part.trim());
            if (!mm) { return; }
            var list = mm[2].split(';').map(function (x) { return x.trim(); })
                .filter(function (x) { return x; });
            out[mm[1].toLowerCase()] = out[mm[1].toLowerCase()].concat(list);
        });
        return (out.remove.length || out.keep.length) ? out : null;
    }

    /* Every note on the page, newest last. Only the innermost element
       holding the text is used, so a note is not read twice. */
    function notesOnPage() {
        var start = NOTE_PREFIX.replace(/:\s*$/, '').toLowerCase();
        var hits = [];
        toArray(document.querySelectorAll('div, p, td, span, pre')).forEach(function (el) {
            if (el.closest('.rce-wi-cell, td.' + COL)) { return; }
            var t = (el.textContent || '').replace(/\s+/g, ' ').trim();
            if (t.toLowerCase().indexOf(start) !== 0) { return; }
            var inner = toArray(el.children).some(function (c) {
                return (c.textContent || '').replace(/\s+/g, ' ').trim()
                    .toLowerCase().indexOf(start) === 0;
            });
            if (!inner) {
                var n = parseNote(t);
                if (n) { hits.push(n); }
            }
        });
        return hits;
    }

    /* The Role Requests table: header row with Operation and Component Name. */
    function findRoleRequestTables() {
        return toArray(document.querySelectorAll('table')).filter(function (t) {
            var hr = t.tHead && t.tHead.rows.length ? t.tHead.rows[0] : t.rows[0];
            if (!hr) { return false; }
            var heads = toArray(hr.cells).map(function (c) {
                return (c.textContent || '').trim().toLowerCase();
            });
            return heads.indexOf('operation') > -1 && heads.indexOf('component name') > -1;
        });
    }

    function renderChanges(cell, note) {
        while (cell.firstChild) { cell.removeChild(cell.firstChild); }
        if (!note) {
            cell.appendChild(document.createTextNode(''));
            return;
        }
        if (note.ambiguous) {
            var msg = document.createElement('div');
            msg.className = 'rce-wi-line rce-wi-ambiguous';
            msg.textContent = 'Several profiles on this application. See the reviewer comment above.';
            cell.appendChild(msg);
            return;
        }
        [['remove', 'Remove'], ['keep', 'Keep']].forEach(function (pair) {
            note[pair[0]].forEach(function (ent) {
                var line = document.createElement('div');
                line.className = 'rce-wi-line rce-wi-' + pair[0];
                var tag = document.createElement('span');
                tag.className = 'rce-wi-tag';
                tag.textContent = pair[1];
                var name = document.createElement('span');
                name.className = 'rce-wi-ent';
                name.textContent = ent;
                line.appendChild(tag);
                line.appendChild(name);
                cell.appendChild(line);
            });
        });
    }

    function workItemSweep() {
        if (!WORKITEM_COLUMN) { return; }
        var tables = findRoleRequestTables();
        if (!tables.length) { return; }
        var notes = notesOnPage();
        if (!notes.length) { return; }          /* no note: page untouched */

        tables.forEach(function (t) {
            var hr = t.tHead && t.tHead.rows.length ? t.tHead.rows[0] : t.rows[0];
            if (!hr.querySelector('.rce-wi-head')) {
                var th = document.createElement(hr.cells[0].tagName.toLowerCase());
                th.className = hr.cells[0].className + ' rce-wi-head';
                th.textContent = WORKITEM_COLUMN_TITLE;
                hr.appendChild(th);
            }
            var compIdx = -1, opIdx = -1;
            toArray(hr.cells).forEach(function (c, i) {
                var h = (c.textContent || '').trim().toLowerCase();
                if (h === 'component name') { compIdx = i; }
                if (h === 'operation') { opIdx = i; }
            });

            /* every Remove Profile row's component text, to spot two
               profiles on the same application */
            var profileComps = [];
            toArray(t.rows).forEach(function (tr) {
                if (tr === hr || tr.parentNode === t.tHead || tr.cells.length < 2) { return; }
                var o = opIdx > -1 && tr.cells[opIdx] ? (tr.cells[opIdx].textContent || '').toLowerCase() : '';
                if (o.indexOf('profile') === -1) { return; }
                profileComps.push(compIdx > -1 && tr.cells[compIdx]
                    ? (tr.cells[compIdx].textContent || '').replace(/\s+/g, ' ') : '');
            });

            toArray(t.rows).forEach(function (tr) {
                if (tr === hr || tr.parentNode === t.tHead) { return; }
                if (tr.cells.length < 2) { return; }
                var cell = tr.querySelector('td.rce-wi-cell');
                if (!cell) {
                    cell = document.createElement('td');
                    cell.className = 'rce-wi-cell';
                    tr.appendChild(cell);
                }
                var comp = compIdx > -1 && tr.cells[compIdx]
                    ? (tr.cells[compIdx].textContent || '').replace(/\s+/g, ' ') : '';
                var op = opIdx > -1 && tr.cells[opIdx]
                    ? (tr.cells[opIdx].textContent || '').toLowerCase() : '';

                /* Match the note to this row by application name. A note
                   without one (written by 4.3 or earlier) is used only
                   when the work item has a single note. */
                var note = null;
                for (var i = notes.length - 1; i >= 0; i--) {
                    if (notes[i].app && comp.indexOf(notes[i].app) > -1) { note = notes[i]; break; }
                }
                if (note) {
                    /* Two profiles on the same application cannot be told
                       apart by the note, so do not guess which one it is. */
                    var sameApp = profileComps.filter(function (c) {
                        return c.indexOf(note.app) > -1;
                    }).length;
                    if (sameApp > 1) { note = { ambiguous: true }; }
                }
                if (!note && notes.length === 1 && !notes[0].app && profileComps.length === 1) {
                    note = notes[0];
                }
                if (op.indexOf('profile') === -1) { note = null; }

                var sig = note ? JSON.stringify(note) : '';
                if (cell.getAttribute('data-sig') === sig) { return; }
                cell.setAttribute('data-sig', sig);
                renderChanges(cell, note);
            });
        });
    }

    /* ---------------------------- the sweep ------------------------------ */

    function sweep() {
        try { workItemSweep(); } catch (e) { /* never break the page */ }
        var grid = findGrid();
        if (!grid) { return; }
        var hr = headerRow(grid);
        if (!hr) { return; }

        var cIdx = headerIndex(hr, CONSTRAINTS_HEADER);
        if (cIdx === -1) { return; }

        if (headerIndex(hr, COLUMN_TITLE) !== -1) { return; }

        var ths = toArray(hr.querySelectorAll('th.' + COL));
        ths.slice(1).forEach(function (n) { n.parentNode.removeChild(n); });
        var th = ths[0] || buildHeaderCell();

        var anchor = headerIndex(hr, INSERT_BEFORE);
        if (anchor === -1) {
            anchor = stockCount(hr);
        }
        placeMirrored(hr, th, anchor);

        var n = stockCellsBefore(hr, th);
        cIdx = headerIndex(hr, CONSTRAINTS_HEADER);


        ownRows(grid).forEach(function (tr) {
            var mine = toArray(tr.cells).filter(function (c) {
                return c.classList.contains(COL);
            });

            if (isGroupRow(tr)) {
                mine.forEach(function (x) { x.parentNode.removeChild(x); });
                return;
            }

            mine.slice(1).forEach(function (x) { x.parentNode.removeChild(x); });
            var td = mine[0];
            if (!td) {
                td = document.createElement('td');
                td.className = COL;
            }

            var text = constraintText(tr, cIdx);

            placeMirrored(tr, td, n);

            var key = keyOf(tr, text);
            if (td.getAttribute('data-key') !== key) {
                td.setAttribute('data-key', key);
            }

            var locked = LOCK_SAVED_ROWS && isLocked(tr);
            var saved = locked ? savedNoteInRow(tr, td) : null;
            var sig = text + (locked ? '\u0001locked' : '') + (saved ? '\u0001' + JSON.stringify(saved) : '');
            if (td.getAttribute('data-src') !== sig) {
                td.setAttribute('data-src', sig);
                if (locked && rowState[key]) {
                    /* decision saved: unsaved marks are no longer relevant */
                    rowState[key].choices = {};
                    rowState[key].savedNote = null;
                }
                renderCell(td, parseConstraints(text), rowState[key], locked, saved);
            }

            if (GUIDE_ROW_DECISION) {
                if (WARNING_TEXT) { updateWarning(td); }
                guideRow(key);
            }
        });
    }

    /* A row is locked when its decision cell shows content (e.g. "Revoked")
       but no Approve / Revoke button: IdentityIQ has saved the decision. */
    function isLocked(tr) {
        var cell = decisionCell(tr);
        if (!cell) { return false; }
        if (nativeButton(tr, 'Approve') || nativeButton(tr, 'Revoke')) { return false; }
        var clone = cell.cloneNode(true);
        toArray(clone.querySelectorAll('.rce-auto-note')).forEach(function (n) {
            n.parentNode.removeChild(n);
        });
        return (clone.textContent || '').replace(/\s+/g, '').length > 0;
    }

    /* The per-entitlement note, if IdentityIQ shows the saved comment
       anywhere inside the row. Returns null when it does not. */
    function savedNoteInRow(tr, td) {
        var start = NOTE_PREFIX.replace(/:\s*$/, '').toLowerCase();
        var found = null;
        toArray(tr.querySelectorAll('*')).some(function (el) {
            if (el.closest('td.' + COL) || el.closest('.rce-auto-note')) { return false; }
            var t = (el.textContent || '').replace(/\s+/g, ' ').trim();
            if (t.toLowerCase().indexOf(start) !== 0) { return false; }
            found = parseNote(t);
            return !!found;
        });
        if (found && found.app) {
            var app = applicationOf(td);
            if (app && app !== found.app) { return null; }
        }
        return found;
    }

    /* ---------------------------- boot ----------------------------------- */

    document.addEventListener('click', function (e) {
        if (blockDecision(e)) { return; }   /* a blocked click does nothing else */
        rememberRow(e.target);
        armFromClick(e.target);
        if (isDecisionClear(e.target)) {
            setTimeout(clearAllMarks, 0);   /* after IdentityIQ's own handler */
        }
    }, true);
    ['mousedown', 'mouseup', 'keydown'].forEach(function (name) {
        document.addEventListener(name, function (e) {
            if (name === 'keydown' && e.key !== 'Enter' && e.key !== ' ') { return; }
            blockDecision(e);
        }, true);
    });

    document.addEventListener('click', function (e) {
        if (!e.target || !e.target.closest) { return; }
        var t = e.target.closest('.rce-toggle');
        if (t) { onToggle(t); return; }
        var n = e.target.closest('.rce-note');
        if (n) { onCopyNote(n); return; }
        var a = e.target.closest('.rce-act');
        if (a) { onEntAct(a); return; }
    });

    document.addEventListener('change', function (e) {
        if (!e.target || !e.target.classList) { return; }
        if (!e.target.classList.contains('rce-mark')) { return; }
        var td = e.target.closest('td.' + COL);
        if (td) {
            updateFoot(td);
            if (WARNING_TEXT) { updateWarning(td); }
        }
    });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', sweep);
    } else {
        sweep();
    }

    if (window.MutationObserver) {
        var queued = false;
        new MutationObserver(function () {
            tryAutofill();
            if (queued) { return; }
            queued = true;
            setTimeout(function () { queued = false; sweep(); }, 150);
        }).observe(document.body, { childList: true, subtree: true });
    }
    setInterval(sweep, SWEEP_MS);

    /* Console helpers for tuning on a real page. */
    window.rceCol = {
        sweep: sweep,
        grid: findGrid,
        note: function () { return lastCell ? noteTextFor(lastCell) : null; },
        field: findCommentField,
        fill: tryAutofill,
        state: function () { return rowState; },
        /* Decision the plugin reads for the row last clicked, plus the
           HTML of its buttons - send this if auto revoke misbehaves. */
        decision: function () {
            var tr = lastCell && lastCell.closest('tr');
            if (!tr) { return 'click a row first'; }
            var a = nativeButton(tr, 'Approve'), r = nativeButton(tr, 'Revoke');
            return {
                revoked: rowRevoked(tr),
                approveButton: a ? a.outerHTML : null,
                revokeButton: r ? r.outerHTML : null
            };
        },
        remove: function () {
            toArray(document.querySelectorAll('.' + COL + ', .rce-auto-note')).forEach(function (n) {
                n.parentNode.removeChild(n);
            });
        },
        headers: function () {
            var g = findGrid(), hr = g && headerRow(g);
            return hr ? toArray(hr.cells).map(function (c) {
                return (c.textContent || '').trim();
            }) : null;
        }
    };

}(window, document));
