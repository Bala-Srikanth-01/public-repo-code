RoleCertEntColumn 4.3
=====================

WHAT IT DOES

Adds a "Role Entitlements" column to the role composition access review
grid, listing each entitlement in the profile on its own line, with an
Approve / Revoke button beside each one.

When you then click IdentityIQ's own Revoke on the row and its comment
dialog opens, the plugin fills the comment box with a note naming the
individual entitlements, for example:

  Per-entitlement review: Remove: Dev-Access | Keep: read-access

Only entitlements the reviewer marked appear. Anything left untouched is
not mentioned either way.

That comment travels through sign-off into the work item raised for the
role owner, so the owner is told exactly which entitlement to take out.


WORK ITEMS ARE RAISED ONLY BY REVOCATION

Approving a row raises no work item, so nothing reaches the role owner
and the note goes nowhere. If anything in the profile needs to change,
the reviewer must REVOKE the row - the comment then says which
entitlements to remove and which to keep.

The plugin shows a reminder in the column as soon as an entitlement is
marked for removal, so this is hard to get wrong by accident.


NEW IN 4.3 - GUIDE, DON'T CLICK

4.2 clicked the row's Revoke for the reviewer, which made IdentityIQ's
comment dialog pop up on every entitlement mark. 4.3 clicks nothing.

While any entitlement on a row is marked Revoke:
  - the row's own Revoke button gets a red outline (pulses twice),
  - the row's Approve button is greyed out and ignores clicks
    (BLOCK_APPROVE), since approving would send nothing to the owner,
  - a short line under the buttons says:
      Revoke required: 1 entitlement marked for removal

The reviewer clicks Revoke themselves. The dialog opens once, with the
per-entitlement note already in the comment box.

Set every mark back to Approve and all of it goes away: Approve works
again and the highlight and line disappear.

If the marks change after the row was revoked, the line reads
"Marks changed. Click Revoke again to update the comment."


STILL NOT CHANGED: THE WORK ITEM TITLE

The role owner's work item still reads as removing the profile. That text
is built on the server at sign-off; a browser plugin cannot change it.
The per-entitlement note is in the work item as the reviewer's comment.


WHAT IT DOES NOT DO

The per-entitlement buttons do NOT record decisions. Only IdentityIQ
writes to its certification tables, and a UI plugin cannot. The row-level
Approve / Revoke is still the decision of record; the buttons only build
the wording of the comment.

Because the note is free text, it is guidance for the role owner, not
structured audit data. You cannot report on it.


BEFORE IT WILL WORK

The certification must be scheduled with "require comments" enabled for
revocation (and approval, if you want notes on approvals too). Without
that, IdentityIQ never opens a comment dialog and there is nothing to
fill.

The role itself is NOT modified. No profiles are split, so role detection
is unchanged - this is the difference from the rule-based approach.


SETTINGS

At the top of ui/js/snippets/entitlementsColumn.js:

  INSERT_BEFORE      which column to sit before        'decision'
  CONSTRAINTS_HEADER column parsed for entitlements    'constraints'
  COLUMN_TITLE       header text                       'Role Entitlements'
  ENT_BUTTONS        show per-entitlement buttons      true
  AUTOFILL_COMMENT   fill the comment dialog           true
  NOTE_PREFIX        text in front of the note
  WARNING_TEXT       reminder to revoke the row ('' = off)
  GUIDE_ROW_DECISION highlight row Revoke on marks    true
  BLOCK_APPROVE      grey out row Approve on marks     true
  GUIDE_NOTE_ONE/MANY line under the decision buttons
  STALE_NOTE         shown if marks change after revoke
  DECISION_HEADER    column with the row buttons       'decision'
  PRESSED_CLASS      classes that mean selected
  MARK_MODE          tick boxes + Copy note button     false
  SKIP_SINGLE        blank the column on split roles   false
  VISIBLE_LINES      lines before "Show more"          3


IF THE COMMENT BOX IS NOT FILLED

Open the browser console on the access review page:

  rceCol.note()    the note for the row last clicked
  rceCol.field()   the comment field it would fill, or null
  rceCol.fill()    force an attempt
  rceCol.decision() whether the plugin sees the row as revoked, plus the
                   HTML of the row's Approve / Revoke buttons
  rceCol.state()    marks remembered per row

If note() is null, no entitlement was marked on that row. If field() is
null, the dialog's box was not recognised - send the dialog's HTML and
the selector can be narrowed.


INSTALL

Global Settings - Plugins - upload the zip. Refresh the access review
page afterwards.
