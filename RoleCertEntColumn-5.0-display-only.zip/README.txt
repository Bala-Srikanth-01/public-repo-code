RoleCertEntColumn 5.0  -  Release 1 (display only)
==================================================

WHAT IT DOES

Adds a "Role Entitlements" column to the role composition access review
grid. For each entitlement profile on a row, the column shows a small
table listing every entitlement the profile grants, one per line:

    Entitlement
    ----------------------------------------
    2207|6412|APP|1004|Underwriter
    2207|6412|APP|1086|Actuary
    2207|6412|APP|1266|RiskEngineer

Without it a reviewer sees only the raw Constraints string, for example
"APPROLE Contains All Of [2207|6412|APP|1004|Underwriter, 2207|6412|
APP|1086|Actuary]", and has to read the entitlements out of it.

Profiles with more than three entitlements show the first three and a
"Show more" link.

Active Directory / LDAP entitlements are handled: a distinguished name
(CN=...,OU=...,DC=...) stays on one line, several DNs in one profile are
listed separately, and commas that are escaped (CN=Smith\, John) or
quoted stay inside the name.


WHAT IT DOES NOT DO IN THIS RELEASE

Nothing except display. The review behaves exactly as it does with the
plugin uninstalled:

  - no per-entitlement Approve / Revoke buttons,
  - IdentityIQ's own Approve / Revoke / Delegate are untouched,
  - no comment is written for the reviewer,
  - the work item page is not changed,
  - nothing is saved anywhere.


WHERE THE DATA COMES FROM

The row itself. The plugin reads the Constraints column already on the
page and formats it. There is no Java, no jar, no REST service, no
database table and no network call - the whole plugin is one JavaScript
file and one stylesheet. Nothing is sent anywhere, and it never runs with
more rights than the signed-in reviewer already has.


INSTALL

  Global Settings - Plugins - New Plugin - upload the zip - install.
  Then refresh the access review page (Ctrl+Shift+R; browsers cache
  plugin JavaScript).

Requires IdentityIQ 8.0 or later. It was built and tested against 8.4.


SETTINGS

At the top of ui/js/snippets/entitlementsColumn.js:

  COLUMN_TITLE       column header       'Role Entitlements'
  INSERT_BEFORE      column to sit before   'decision'
  CONSTRAINTS_HEADER column read for the entitlements  'constraints'
  VISIBLE_LINES      lines before "Show more"   3
  TABLE_ENT_HEADING  table header        'Entitlement'
  SWEEP_MS           re-check interval, ms      1500


BEFORE PRODUCTION

The snippet's regexPattern in manifest.xml is ".*", so the plugin loads
on every IdentityIQ page and does nothing unless it finds a grid with a
Constraints column. Narrowing it to the certification URL is worth doing
for production.


THE NEXT RELEASE

The reviewer-decision features are written and tested; they are switched
off in this build by one line near the top of the JavaScript file:

    var DISPLAY_ONLY = true;

Set it to false and the same file also gives:

  - Approve / Revoke beside each entitlement, with a Decision column in
    the table; clicking a selected button again clears it,
  - the row's own Revoke greyed out until an entitlement is marked
    Revoke, and Approve greyed out once one is,
  - the reviewer's choices written into the revoke comment, one
    entitlement per line, so the role owner is told which to remove,
  - an "Entitlement Changes" column on the role owner's work item,
    listing the entitlements to be removed,
  - rows that IdentityIQ has already decided become read-only.

Note for that release: the note reaches the role owner through the
decision comment, so the certification has to be scheduled with comments
required on revocation. The full notes for those features are in
README-full-4.13.1.txt.
