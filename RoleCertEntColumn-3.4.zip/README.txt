RoleCertEntColumn v3.4
======================

ONE JOB: adds a "Role Entitlements" column to the role composition access
review grid, with each entitlement on its own line.

It touches nothing else. Checkboxes, Bulk Decisions, the "Role: X" group
rows, Approve/Revoke, paging, sorting - all stock IdentityIQ, left exactly
as they are. Earlier versions of this plugin hid the group rows and added
badges; that has all been removed.


WHERE THE DATA COMES FROM
-------------------------
The row already carries it. A role composition access review shows the
entitlement profile in the Constraints column as one dense line:

  EntitlementValue Contains All Of [Administrators + PWCHFSSGFTP01,
  Administrators + pwgsdscs3308001, Domain Users + pwchfssgclp01]

The plugin parses that and prints:

  Administrators + PWCHFSSGFTP01
  Administrators + pwgsdscs3308001
  Domain Users + pwchfssgclp01

Real data, from the page you are already looking at. No Java, no jar, no
REST endpoint, no database, no configuration.


INSTALL
-------
Global Settings -> Plugins -> New Plugin -> upload this zip -> Install.
Open a role composition access review. Uninstall any earlier version of
this plugin first, or install over it (same plugin name, version 2.0.0.0).


SETTINGS (top of ui/js/snippets/entitlementsColumn.js)
-----------------------------------------------------
  INSERT_BEFORE       'decision' - insert the column before the Decision
                      column so it is visible without scrolling. Set to ''
                      to append it last instead.
  CONSTRAINTS_HEADER  'constraints' - the column that is parsed. The cell
                      is found by header text, so reordering columns with
                      the Columns menu does not break it.
  COLUMN_TITLE        'Role Entitlements'
  VISIBLE_LINES       3 - lines before "Show more". Set to 0 for no limit.


NOTES
-----
- regexPattern is ".*" (all pages), the same approach as SailPoint's own
  Todo plugin example. This is deliberate: the responsive access review is
  an Angular single-page app served from .../ui/index.jsf, and the
  "certification" part of the URL lives in the # fragment, which the
  server never sees - so a pattern like ".*certification.*" never matches
  and the script never runs. The script exits immediately on any page
  without a Constraints column, so the cost elsewhere is negligible.
- The column is only added to a grid that has a Constraints column, so
  other IdentityIQ tables are never touched.
- The sweep is idempotent: every pass enforces exactly one header cell and
  one cell per row, so grid repaints on sort/page/filter cannot produce
  duplicate cells or mismatched fonts.
- Expanded rows stay expanded: a cell is only re-rendered if its source
  text actually changed.
- Group ("Role: X") rows deliberately get no cell - they span the full
  width, and adding one would break column alignment.
- If a row has no constraint text, the cell is left blank rather than
  filled with placeholder text.
- Since Constraints now duplicates this information, you may want to hide
  Constraints via the grid's Columns menu.


IF THE COLUMN DOES NOT APPEAR
-----------------------------
In the browser console on the access review page:
  rceCol.headers()   - the grid headers the plugin can see
  rceCol.grid()      - the table element it picked
  rceCol.sweep()     - run the injection again
  rceCol.remove()    - remove the column
If rceCol is undefined the snippet is not loading at all (check the plugin
is installed and enabled). If rceCol.grid() returns null the grid is not a
real <table> and the injection needs retargeting - send the row's
outerHTML.


v2.1 FIXES
----------
1. COLUMN ALIGNMENT. v2.0 positioned cells using raw cellIndex numbers.
   Once our own cell was in a row, the index counted it too, so each sweep
   nudged the column one place further along and the header drifted out of
   line with the body - which is why the stock Constraints text appeared
   under the "Role Entitlements" heading. Positions are now expressed as a
   count of STOCK cells (ignoring our own), so repeated sweeps cannot move
   anything.
2. LDAP DNs ARE NO LONGER SPLIT. A constraint like
     Group Membership Contains All Of [CN=Dev Group Admin,OU=DEV USERS,
     DC=seri,DC=sailpointdemo,DC=com]
   is ONE entitlement whose distinguished name happens to contain commas.
   Splitting on every comma produced four meaningless fragments. Pieces
   starting with an LDAP prefix (CN=, OU=, DC=, O=, UID=, ...) are now
   rejoined to the preceding piece. A plain list such as
     Contains All Of [AcctsPayableAccess, AcctsPayableAccess1,
     AcctsReceivableAccess]
   still splits into three lines as before.
3. Rows with an unexpected shape fall back to scanning for the constraint
   text rather than showing nothing.


v3.0 - MARKING ENTITLEMENTS FOR REMOVAL
---------------------------------------
Each entitlement line now has a small tick box. A reviewer ticks the ones
they think should come out of the profile, clicks "Copy note", and pastes
the result into the row's stock Comments box:

  Remove: Domain Users + pwchfssgclp01 | Keep: Administrators +
  PWCHFSSGFTP01; Administrators + pwgsdscs3308001

WHAT THE TICK DOES AND DOES NOT DO
  - It does NOT change the role.
  - It does NOT record a decision in IdentityIQ.
  - It only builds text. The stock Approve/Revoke decision and the stock
    comment are the things IdentityIQ actually saves.
The tick box is deliberately small and square so it cannot be mistaken for
the stock decision checkbox, and the cell carries the hint "ticks build a
note, not a decision". A control that looked like a decision but saved
nothing would be an audit hazard on a compliance screen.

Ticks are held in the page only. Sorting or paging the grid keeps them;
reloading the page clears them. Copy the note before navigating away.

WHY IT WORKS THIS WAY
IdentityIQ's Approve/Revoke acts on the whole row, i.e. on the entire
profile - there is no built-in way to approve two entitlements and revoke a
third. Recording the reviewer's intent as a comment keeps the audit trail
inside the certification, where per-cycle decisions belong, and leaves the
role itself untouched. Changing a profile changes the role for EVERY
identity that holds it, so that change belongs in the role approval
process, not in a review screen.

Set MARK_MODE = false at the top of the JS for a display-only column.

NEXT STEP IF NEEDED
To have the reviewer's marks raise a real role-change request through
IdentityIQ's role approval workflow, the Java/REST side of the plugin is
required. That keeps approvals and change history intact, unlike editing
the role directly from the review screen.


v3.1 - QUIET ON SPLIT ROLES
---------------------------
Once a role's profiles are split so each holds ONE entitlement, the
certification already shows one row per entitlement, and the Constraints
column beside us already reads clearly. Repeating that in our column is
just noise, so rows with a single entitlement are now left blank.

  Row with 3 entitlements  -> column lists all 3, with tick boxes
  Row with 1 entitlement   -> column stays empty

This means one plugin works across both kinds of role while you migrate:
it helps on the roles you have not split yet, and gets out of the way on
the ones you have.

Set SKIP_SINGLE = false at the top of the JS to always fill the column.

WHEN TO RETIRE THIS PLUGIN
If every role ends up split, this column will be blank everywhere and the
plugin can be uninstalled. That is the intended end state, not a failure.


v3.2
----
1. The column now fills on EVERY row, including rows holding a single
   entitlement. v3.1 left those blank to avoid repeating the Constraints
   column; that made split roles look like the plugin was broken.
   SKIP_SINGLE = true restores the v3.1 behaviour.
2. Tick boxes are OFF by default (MARK_MODE = false). Once roles are split,
   each row has a real Approve/Revoke, so a tick box that only builds a
   note sits awkwardly beside a real decision. Set MARK_MODE = true to
   bring it back for roles that have not been split.
3. The column is not injected if the grid already shows a column with the
   same title, so an older copy of the plugin cannot produce two.


v3.3 - DEMO APPROVE / REVOKE BUTTONS
------------------------------------
Each entitlement line now shows an Approve and a Revoke button, to
demonstrate what per-entitlement decisions would look like.

THEY RECORD NOTHING. Clicking Approve turns the entitlement green;
Revoke turns it red and strikes it through. That state lives in the
browser only. No decision reaches IdentityIQ, because only IdentityIQ's
own buttons write to its database - a plugin draws on the page and
cannot create a decision record.

v3.4 removed the DEMO tag and the on-click note at the presenter's
request, so the buttons now look like ordinary buttons. The only
remaining marker is the tooltip on hover. Because of that, UNINSTALL OR
SET DEMO_BUTTONS = false ONCE THE DEMONSTRATION IS OVER. Left enabled on
a live access review, a reviewer could click through every line, sign
off, and IdentityIQ would hold no decisions at all.

Set DEMO_BUTTONS = false at the top of the JS to remove them.

FOR REAL PER-ENTITLEMENT DECISIONS
Split the role's profiles so each holds one entitlement. The
certification then produces one row per entitlement with genuine
Approve/Revoke supplied by IdentityIQ. See the Split Entitlement
Profiles rule.
