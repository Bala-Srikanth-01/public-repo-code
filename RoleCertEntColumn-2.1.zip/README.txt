RoleCertEntColumn v2.1
======================

ONE JOB: adds a "Role Entitlements" column to the role composition access
review grid, with each entitlement on its own line.

It touches nothing else. Checkboxes, Bulk Decisions, the "Role: X" group
rows, Approve/Revoke, paging, sorting - all stock IdentityIQ, left exactly
as they are. Earlier versions of this plugin hid the group rows and added
badges; that has all been removed.


WHERE THE DATA COMES FROM
-------------------------
The row already carries it. A role composition access review shows the
entitlement profile in the Constraints column as one dense line:

  EntitlementValue Contains All Of [Administrators + PWCHFSSGFTP01,
  Administrators + pwgsdscs3308001, Domain Users + pwchfssgclp01]

The plugin parses that and prints:

  Administrators + PWCHFSSGFTP01
  Administrators + pwgsdscs3308001
  Domain Users + pwchfssgclp01

Real data, from the page you are already looking at. No Java, no jar, no
REST endpoint, no database, no configuration.


INSTALL
-------
Global Settings -> Plugins -> New Plugin -> upload this zip -> Install.
Open a role composition access review. Uninstall any earlier version of
this plugin first, or install over it (same plugin name, version 2.0.0.0).


SETTINGS (top of ui/js/snippets/entitlementsColumn.js)
-----------------------------------------------------
  INSERT_BEFORE       'decision' - insert the column before the Decision
                      column so it is visible without scrolling. Set to ''
                      to append it last instead.
  CONSTRAINTS_HEADER  'constraints' - the column that is parsed. The cell
                      is found by header text, so reordering columns with
                      the Columns menu does not break it.
  COLUMN_TITLE        'Role Entitlements'
  VISIBLE_LINES       3 - lines before "Show more". Set to 0 for no limit.


NOTES
-----
- regexPattern is ".*" (all pages), the same approach as SailPoint's own
  Todo plugin example. This is deliberate: the responsive access review is
  an Angular single-page app served from .../ui/index.jsf, and the
  "certification" part of the URL lives in the # fragment, which the
  server never sees - so a pattern like ".*certification.*" never matches
  and the script never runs. The script exits immediately on any page
  without a Constraints column, so the cost elsewhere is negligible.
- The column is only added to a grid that has a Constraints column, so
  other IdentityIQ tables are never touched.
- The sweep is idempotent: every pass enforces exactly one header cell and
  one cell per row, so grid repaints on sort/page/filter cannot produce
  duplicate cells or mismatched fonts.
- Expanded rows stay expanded: a cell is only re-rendered if its source
  text actually changed.
- Group ("Role: X") rows deliberately get no cell - they span the full
  width, and adding one would break column alignment.
- If a row has no constraint text, the cell is left blank rather than
  filled with placeholder text.
- Since Constraints now duplicates this information, you may want to hide
  Constraints via the grid's Columns menu.


IF THE COLUMN DOES NOT APPEAR
-----------------------------
In the browser console on the access review page:
  rceCol.headers()   - the grid headers the plugin can see
  rceCol.grid()      - the table element it picked
  rceCol.sweep()     - run the injection again
  rceCol.remove()    - remove the column
If rceCol is undefined the snippet is not loading at all (check the plugin
is installed and enabled). If rceCol.grid() returns null the grid is not a
real <table> and the injection needs retargeting - send the row's
outerHTML.


v2.1 FIXES
----------
1. COLUMN ALIGNMENT. v2.0 positioned cells using raw cellIndex numbers.
   Once our own cell was in a row, the index counted it too, so each sweep
   nudged the column one place further along and the header drifted out of
   line with the body - which is why the stock Constraints text appeared
   under the "Role Entitlements" heading. Positions are now expressed as a
   count of STOCK cells (ignoring our own), so repeated sweeps cannot move
   anything.
2. LDAP DNs ARE NO LONGER SPLIT. A constraint like
     Group Membership Contains All Of [CN=Dev Group Admin,OU=DEV USERS,
     DC=seri,DC=sailpointdemo,DC=com]
   is ONE entitlement whose distinguished name happens to contain commas.
   Splitting on every comma produced four meaningless fragments. Pieces
   starting with an LDAP prefix (CN=, OU=, DC=, O=, UID=, ...) are now
   rejoined to the preceding piece. A plain list such as
     Contains All Of [AcctsPayableAccess, AcctsPayableAccess1,
     AcctsReceivableAccess]
   still splits into three lines as before.
3. Rows with an unexpected shape fall back to scanning for the constraint
   text rather than showing nothing.
