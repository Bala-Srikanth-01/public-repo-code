/*
 * RoleCertEntColumn v2.0
 *
 * ONE JOB: add a "Role Entitlements" column to the role composition
 * access review grid, with each entitlement on its own line.
 *
 * It does NOT touch anything else on the page. Checkboxes, Bulk
 * Decisions, the "Role: X" group rows, Approve/Revoke, paging - all
 * stock IdentityIQ, left exactly as they are.
 *
 * WHERE THE DATA COMES FROM
 * -------------------------
 * The row already carries it. A role composition access review shows the
 * entitlement profile in the Constraints column, as one dense line:
 *
 *   EntitlementValue Contains All Of [Administrators + PWCHFSSGFTP01,
 *   Administrators + pwgsdscs3308001, Domain Users + pwchfssgclp01]
 *
 * We parse that and print:
 *
 *   Administrators + PWCHFSSGFTP01
 *   Administrators + pwgsdscs3308001
 *   Domain Users + pwchfssgclp01
 *
 * Real data. No Java, no jar, no REST endpoint, no database.
 *
 * WHY THE SWEEP RUNS REPEATEDLY
 * -----------------------------
 * The grid repaints its rows on sort / page / filter. Rather than inject
 * once and hope, every pass enforces exactly ONE header cell and ONE cell
 * per row at the same column index, removing any extras. Running it twice
 * changes nothing, so repaints are harmless. This is what stops the
 * duplicate cells and mismatched fonts seen in earlier versions.
 */
(function (window, document) {
    'use strict';

    /* ------------------------------ CONFIG ------------------------------ */

    /* Column header text to insert BEFORE, so the new column is visible
       without scrolling past the wide Decision column. Case insensitive.
       Set to '' to append the column last instead. */
    var INSERT_BEFORE = 'decision';

    /* Column header holding the constraint string we parse. */
    var CONSTRAINTS_HEADER = 'constraints';

    /* Our column's header text. */
    var COLUMN_TITLE = 'Role Entitlements';

    /* Entitlement lines shown before "Show more". Set to 0 for no limit. */
    var VISIBLE_LINES = 3;

    /* Safety-net re-check interval, ms. The MutationObserver catches
       repaints much faster; this only covers anything it misses. */
    var SWEEP_MS = 1500;

    /* --------------------------------------------------------------------- */

    var COL = 'rce-col';

    function toArray(nl) { return Array.prototype.slice.call(nl); }

    /* ---------------------------- find the grid -------------------------- */

    /* The certification grid is the largest table on the page that has a
       thead and is not nested inside another cell. Deliberately structural
       rather than class-based: IIQ grid class names differ across versions
       and skins, and a wrong class name would mean no column at all. */
    function findGrid() {
        var best = null, bestRows = 0;
        toArray(document.querySelectorAll('table')).forEach(function (t) {
            if (!t.tHead || !t.tBodies.length) { return; }
            if (t.parentNode && t.parentNode.closest &&
                t.parentNode.closest('td, th')) { return; }
            var n = t.tBodies[0].rows.length;
            if (n > bestRows) { best = t; bestRows = n; }
        });
        return best;
    }

    function headerRow(grid) {
        return (grid.tHead && grid.tHead.rows.length)
            ? grid.tHead.rows[grid.tHead.rows.length - 1]
            : null;
    }

    /* Position of the header cell whose text starts with `title`,
     * expressed as THE NUMBER OF STOCK CELLS BEFORE IT - not as a raw
     * cellIndex. This matters: once our own cell is in the row, a raw
     * index counts it too, and every sweep would shift the column one
     * place further along. Counting only stock cells is stable.
     * Returns -1 if not found. */
    function headerIndex(hr, title) {
        if (!title) { return -1; }
        var want = title.toLowerCase(), n = 0;
        for (var i = 0; i < hr.cells.length; i++) {
            var c = hr.cells[i];
            if (c.classList.contains(COL)) { continue; }
            var t = (c.textContent || '').trim().toLowerCase();
            if (t === want || t.indexOf(want) === 0) { return n; }
            n++;
        }
        return -1;
    }

    /* The nth stock cell of a row (ignoring our own cell). */
    function stockCellAt(row, n) {
        var seen = 0;
        for (var i = 0; i < row.cells.length; i++) {
            var c = row.cells[i];
            if (c.classList.contains(COL)) { continue; }
            if (seen === n) { return c; }
            seen++;
        }
        return null;
    }

    /* Total stock cells in a row. */
    function stockCount(row) {
        var n = 0;
        for (var i = 0; i < row.cells.length; i++) {
            if (!row.cells[i].classList.contains(COL)) { n++; }
        }
        return n;
    }

    /* Rows belonging to this grid only, never rows of a nested table. */
    function ownRows(grid) {
        var rows = [];
        toArray(grid.tBodies).forEach(function (tb) {
            if (tb.parentNode !== grid) { return; }
            toArray(tb.rows).forEach(function (tr) {
                if (tr.closest('table') === grid) { rows.push(tr); }
            });
        });
        return rows;
    }

    /* ------------------------ placement ---------------------------------
     * Numeric cellIndex arithmetic drifts as soon as our own cell is in
     * the row, or a row has a different number of cells from the header.
     * When it drifts, a stock cell ends up under our header - which is
     * exactly the "raw Constraints text under Role Entitlements" symptom.
     *
     * Instead we mirror an anchor: our cell always goes before the Nth
     * STOCK cell (ignoring our own), where N is the same number used in
     * the header. Counting only stock cells makes this stable no matter
     * how often the sweep runs.
     * ------------------------------------------------------------------ */

    /* Number of stock cells that precede our cell in the header. */
    function stockCellsBefore(row, node) {
        var n = 0;
        for (var i = 0; i < row.cells.length; i++) {
            if (row.cells[i] === node) { return n; }
            if (!row.cells[i].classList.contains(COL)) { n++; }
        }
        return n;
    }

    /* Insert `node` into `row` so that exactly `n` stock cells precede it. */
    function placeMirrored(row, node, n) {
        var seen = 0, ref = null;
        for (var i = 0; i < row.cells.length; i++) {
            var c = row.cells[i];
            if (c === node) { continue; }
            if (seen === n) { ref = c; break; }
            if (!c.classList.contains(COL)) { seen++; }
        }
        if (node.parentNode === row && node.nextElementSibling === ref) {
            return;                       /* already in the right place */
        }
        row.insertBefore(node, ref);
    }

    /* The row's constraint text. Uses the header index, but falls back to
       scanning the row when that cell holds nothing bracket-like - so a
       row with an unexpected shape still renders instead of showing raw
       text or nothing. */
    function constraintText(tr, cIdx) {
        var cell = (cIdx > -1) ? stockCellAt(tr, cIdx) : null;
        if (cell) {
            var t = cell.textContent || '';
            if (t.indexOf('[') > -1) { return t; }
        }
        /* fallback: a row with an unexpected shape still renders */
        for (var i = 0; i < tr.cells.length; i++) {
            var c = tr.cells[i];
            if (c.classList.contains(COL)) { continue; }
            var s2 = c.textContent || '';
            if (s2.indexOf('[') > -1 && /contains|equals|\+/i.test(s2)) {
                return s2;
            }
        }
        return cell ? (cell.textContent || '') : '';
    }

    /* A "Role: X" group header row spans the grid. It gets no cell of its
       own - adding one would push the real columns out of alignment.
       It is otherwise left completely alone. */
    function isGroupRow(tr) {
        for (var i = 0; i < tr.cells.length; i++) {
            if (tr.cells[i].colSpan > 1) { return true; }
        }
        return false;
    }

    /* ---------------------------- parse ---------------------------------- */

    /* Pull the entitlements out of a constraint string.
     *
     * Two real formats, both from live role composition reviews:
     *
     *   Contains All Of [AcctsPayableAccess, AcctsPayableAccess1,
     *                    AcctsReceivableAccess]
     *     -> three separate entitlements, split on commas.
     *
     *   Group Membership Contains All Of [CN=Dev Group Admin,OU=DEV
     *                    USERS,DC=seri,DC=sailpointdemo,DC=com]
     *     -> ONE entitlement: an LDAP distinguished name that happens to
     *        contain commas. Splitting it would produce four meaningless
     *        fragments, so DN components are kept together.
     *
     * The rule: split on commas, then re-join any piece that begins with
     * an LDAP attribute prefix (CN=, OU=, DC=, O=, UID=, ...) onto the
     * previous piece, since it is a continuation of the same DN.
     *
     * If there are no brackets the whole string is shown as one line
     * rather than nothing, so no data is ever silently dropped.
     */
    var DN_PART = /^(cn|ou|dc|o|l|st|c|uid|dn|sn|email|mail)\s*=/i;

    function splitList(inner) {
        var parts = inner.split(','), out = [];
        parts.forEach(function (raw) {
            var v = raw.trim();
            if (!v) { return; }
            if (out.length && DN_PART.test(v) && DN_PART.test(out[out.length - 1])) {
                out[out.length - 1] += ',' + v;   /* same DN, keep together */
            } else {
                out.push(v);
            }
        });
        return out;
    }

    function parseConstraints(text) {
        if (!text) { return []; }
        var out = [], re = /\[([^\]]*)\]/g, m;
        while ((m = re.exec(text)) !== null) {
            splitList(m[1].replace(/\s+/g, ' ')).forEach(function (v) {
                out.push(v);
            });
        }
        if (!out.length) {
            var t = text.replace(/\s+/g, ' ').trim();
            if (t) { out.push(t); }
        }
        return out;
    }

    /* ---------------------------- render --------------------------------- */

    function buildHeaderCell() {
        var th = document.createElement('th');
        th.className = COL;
        th.textContent = COLUMN_TITLE;
        return th;
    }

    function renderCell(td, ents) {
        while (td.firstChild) { td.removeChild(td.firstChild); }
        if (!ents.length) { return; }          /* blank cell, no filler text */

        var limit = (VISIBLE_LINES > 0) ? VISIBLE_LINES : ents.length;

        var wrap = document.createElement('div');
        wrap.className = 'rce-lines';
        ents.forEach(function (e, i) {
            var line = document.createElement('div');
            line.className = 'rce-line' + (i >= limit ? ' rce-hide' : '');
            line.textContent = e;
            wrap.appendChild(line);
        });
        td.appendChild(wrap);

        if (ents.length > limit) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'rce-toggle';
            btn.textContent = 'Show ' + (ents.length - limit) + ' more';
            td.appendChild(btn);
            /* No listener here: one delegated listener on the document
               (see bottom) survives grids that repaint by re-serializing
               their HTML, which silently drops node listeners. */
        }
    }

    function onToggle(btn) {
        var wrap = btn.parentNode.querySelector('.rce-lines');
        if (!wrap) { return; }
        var expand = !!wrap.querySelector('.rce-hide');
        var limit = (VISIBLE_LINES > 0) ? VISIBLE_LINES : wrap.children.length;
        toArray(wrap.children).forEach(function (line, i) {
            line.classList.toggle('rce-hide', !expand && i >= limit);
        });
        btn.textContent = expand
            ? 'Show less'
            : 'Show ' + (wrap.children.length - limit) + ' more';
    }

    /* ---------------------------- the sweep ------------------------------ */

    function sweep() {
        var grid = findGrid();
        if (!grid) { return; }
        var hr = headerRow(grid);
        if (!hr) { return; }

        /* Only act on a grid that has a Constraints column, so other
           IdentityIQ tables are never touched. */
        var cIdx = headerIndex(hr, CONSTRAINTS_HEADER);
        if (cIdx === -1) { return; }

        /* HEADER: exactly one of ours, before the anchor column. */
        var ths = toArray(hr.querySelectorAll('th.' + COL));
        ths.slice(1).forEach(function (n) { n.parentNode.removeChild(n); });
        var th = ths[0] || buildHeaderCell();

        var anchor = headerIndex(hr, INSERT_BEFORE);   /* stock index */
        if (anchor === -1) {
            anchor = stockCount(hr);   /* no anchor column: place last */
        }
        placeMirrored(hr, th, anchor);

        /* how many stock cells actually precede our header now - this is
           the single number every row mirrors */
        var n = stockCellsBefore(hr, th);
        cIdx = headerIndex(hr, CONSTRAINTS_HEADER);

        /* ROWS */
        ownRows(grid).forEach(function (tr) {
            var mine = toArray(tr.cells).filter(function (c) {
                return c.classList.contains(COL);
            });

            if (isGroupRow(tr)) {
                mine.forEach(function (x) { x.parentNode.removeChild(x); });
                return;
            }

            mine.slice(1).forEach(function (x) { x.parentNode.removeChild(x); });
            var td = mine[0];
            if (!td) {
                td = document.createElement('td');
                td.className = COL;
            }

            /* read the source BEFORE moving our cell, so the scan cannot
               be confused by our own cell's position */
            var text = constraintText(tr, cIdx);

            placeMirrored(tr, td, n);

            /* re-render only when the source changed, so an expanded row
               is not collapsed by the next sweep */
            if (td.getAttribute('data-src') === text) { return; }
            td.setAttribute('data-src', text);
            renderCell(td, parseConstraints(text));
        });
    }

    /* ---------------------------- boot ----------------------------------- */

    document.addEventListener('click', function (e) {
        var btn = e.target && e.target.closest
                ? e.target.closest('.rce-toggle') : null;
        if (btn) { onToggle(btn); }
    });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', sweep);
    } else {
        sweep();
    }

    if (window.MutationObserver) {
        var queued = false;
        new MutationObserver(function () {
            if (queued) { return; }
            queued = true;
            setTimeout(function () { queued = false; sweep(); }, 150);
        }).observe(document.body, { childList: true, subtree: true });
    }
    setInterval(sweep, SWEEP_MS);

    /* Console helpers for tuning on a real page. */
    window.rceCol = {
        sweep: sweep,
        grid: findGrid,
        remove: function () {
            toArray(document.querySelectorAll('.' + COL)).forEach(function (n) {
                n.parentNode.removeChild(n);
            });
        },
        headers: function () {
            var g = findGrid(), hr = g && headerRow(g);
            return hr ? toArray(hr.cells).map(function (c) {
                return (c.textContent || '').trim();
            }) : null;
        }
    };

}(window, document));
