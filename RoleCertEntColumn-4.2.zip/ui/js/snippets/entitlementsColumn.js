/*
 * RoleCertEntColumn v4.2
 *
 * ONE JOB: add a "Role Entitlements" column to the role composition
 * access review grid, with each entitlement on its own line.
 *
 * It does NOT touch anything else on the page. Checkboxes, Bulk
 * Decisions, the "Role: X" group rows, Approve/Revoke, paging - all
 * stock IdentityIQ, left exactly as they are.
 *
 * WHERE THE DATA COMES FROM
 * -------------------------
 * The row already carries it. A role composition access review shows the
 * entitlement profile in the Constraints column, as one dense line:
 *
 *   EntitlementValue Contains All Of [Administrators + PWCHFSSGFTP01,
 *   Administrators + pwgsdscs3308001, Domain Users + pwchfssgclp01]
 *
 * We parse that and print:
 *
 *   Administrators + PWCHFSSGFTP01
 *   Administrators + pwgsdscs3308001
 *   Domain Users + pwchfssgclp01
 *
 * Real data. No Java, no jar, no REST endpoint, no database.
 *
 * WHY THE SWEEP RUNS REPEATEDLY
 * -----------------------------
 * The grid repaints its rows on sort / page / filter. Rather than inject
 * once and hope, every pass enforces exactly ONE header cell and ONE cell
 * per row at the same column index, removing any extras. Running it twice
 * changes nothing, so repaints are harmless. This is what stops the
 * duplicate cells and mismatched fonts seen in earlier versions.
 */
(function (window, document) {
    'use strict';

    /* ------------------------------ CONFIG ------------------------------ */

    /* Column header text to insert BEFORE, so the new column is visible
       without scrolling past the wide Decision column. Case insensitive.
       Set to '' to append the column last instead. */
    var INSERT_BEFORE = 'decision';

    /* Column header holding the constraint string we parse. */
    var CONSTRAINTS_HEADER = 'constraints';

    /* Our column's header text. */
    var COLUMN_TITLE = 'Role Entitlements';

    /* Show a tick box beside each entitlement so a reviewer can mark which
       ones they think should come out of the profile, then copy that as a
       note to paste into the stock Comments box. The tick itself records
       NOTHING in IdentityIQ - the stock Approve/Revoke decision and the
       comment are what get saved. Set false for a display-only column. */
    var MARK_MODE = false;

    /* A role whose profiles have been split already shows ONE entitlement
       per row, and the Constraints column right next to us says the same
       thing. Repeating it adds noise, so those rows are left blank.
       Set false to always fill the column. */
    var SKIP_SINGLE = false;

    /* Approve / Revoke buttons beside each entitlement. These do NOT write
       a decision - only IdentityIQ's own row buttons do that. What they do
       is build the note that goes into the stock Comments box, so the role
       owner is told exactly which entitlement to take out. */
    var ENT_BUTTONS = true;

    /* When IdentityIQ opens its comment dialog after Revoke, put the note
       for that row into the comment box automatically. The reviewer can
       still edit or clear it before saving. Set false to leave the box
       empty and use the Copy note button instead. */
    var AUTOFILL_COMMENT = true;

    /* Text put in front of the note, so the role owner sees at a glance
       that it lists individual entitlements. '' for no prefix. */
    var NOTE_PREFIX = 'Per-entitlement review: ';

    /* Shown under the entitlements once one is marked for removal.
       Set to '' to switch the warning off. */
    var WARNING_TEXT = 'Revoke the row to send this to the role owner. '
                     + 'Approving the row raises no work item.';

    /* ---- 4.2: keep the row decision in step with the entitlements ----

       AUTO_ROW_DECISION
         Mark any entitlement Revoke  -> the plugin clicks the row's own
                                         IdentityIQ Revoke button.
         Set every mark back to Approve -> the plugin clicks the row's
                                         Approve button, and the revoke
                                         comment goes with the old decision.
         The plugin only ever reverses a Revoke it made itself. A row the
         reviewer revoked by hand is never switched back.
       Set false to go back to 4.1 behaviour (warning only). */
    var AUTO_ROW_DECISION = true;

    /* After an automatic Revoke, IdentityIQ may open its comment dialog.
       true  = the plugin fills the note AND presses the dialog's Save, so
               the reviewer cannot skip or clear the comment.
       false = the note is filled and the reviewer presses Save. */
    var AUTO_SAVE_DIALOG = true;

    /* Short line shown under the row's decision buttons after an automatic
       Revoke. {n} is replaced by the count. '' = no line. */
    var AUTO_NOTE_ONE  = 'Auto-revoked: 1 entitlement marked for removal';
    var AUTO_NOTE_MANY = 'Auto-revoked: {n} entitlements marked for removal';

    /* Shown when the marks change after a Revoke and the plugin cannot
       refresh the comment itself. */
    var STALE_NOTE = 'Marks changed after revoke. Click Revoke again to update the comment.';

    /* Column holding IdentityIQ's own Approve / Revoke buttons. */
    var DECISION_HEADER = 'decision';

    /* How the plugin recognises which stock row button is selected.
       IdentityIQ skins differ; if rceCol.decision() in the console reports
       'unknown' on a decided row, add the selected button's class here. */
    var PRESSED_CLASS = /(^|\s)(active|selected|pressed|checked|btn-success|btn-danger|is-selected)(\s|$)/i;

    /* Entitlement lines shown before "Show more". Set to 0 for no limit. */
    var VISIBLE_LINES = 3;

    /* Safety-net re-check interval, ms. The MutationObserver catches
       repaints much faster; this only covers anything it misses. */
    var SWEEP_MS = 1500;

    /* --------------------------------------------------------------------- */

    var COL = 'rce-col';

    function toArray(nl) { return Array.prototype.slice.call(nl); }

    /* ---------------------------- find the grid -------------------------- */

    /* The certification grid is the largest table on the page that has a
       thead and is not nested inside another cell. Deliberately structural
       rather than class-based: IIQ grid class names differ across versions
       and skins, and a wrong class name would mean no column at all. */
    function findGrid() {
        var best = null, bestRows = 0;
        toArray(document.querySelectorAll('table')).forEach(function (t) {
            if (!t.tHead || !t.tBodies.length) { return; }
            if (t.parentNode && t.parentNode.closest &&
                t.parentNode.closest('td, th')) { return; }
            var n = t.tBodies[0].rows.length;
            if (n > bestRows) { best = t; bestRows = n; }
        });
        return best;
    }

    function headerRow(grid) {
        return (grid.tHead && grid.tHead.rows.length)
            ? grid.tHead.rows[grid.tHead.rows.length - 1]
            : null;
    }

    /* Position of the header cell whose text starts with `title`,
     * expressed as THE NUMBER OF STOCK CELLS BEFORE IT - not as a raw
     * cellIndex. This matters: once our own cell is in the row, a raw
     * index counts it too, and every sweep would shift the column one
     * place further along. Counting only stock cells is stable.
     * Returns -1 if not found. */
    function headerIndex(hr, title) {
        if (!title) { return -1; }
        var want = title.toLowerCase(), n = 0;
        for (var i = 0; i < hr.cells.length; i++) {
            var c = hr.cells[i];
            if (c.classList.contains(COL)) { continue; }
            var t = (c.textContent || '').trim().toLowerCase();
            if (t === want || t.indexOf(want) === 0) { return n; }
            n++;
        }
        return -1;
    }

    /* The nth stock cell of a row (ignoring our own cell). */
    function stockCellAt(row, n) {
        var seen = 0;
        for (var i = 0; i < row.cells.length; i++) {
            var c = row.cells[i];
            if (c.classList.contains(COL)) { continue; }
            if (seen === n) { return c; }
            seen++;
        }
        return null;
    }

    /* Total stock cells in a row. */
    function stockCount(row) {
        var n = 0;
        for (var i = 0; i < row.cells.length; i++) {
            if (!row.cells[i].classList.contains(COL)) { n++; }
        }
        return n;
    }

    /* Rows belonging to this grid only, never rows of a nested table. */
    function ownRows(grid) {
        var rows = [];
        toArray(grid.tBodies).forEach(function (tb) {
            if (tb.parentNode !== grid) { return; }
            toArray(tb.rows).forEach(function (tr) {
                if (tr.closest('table') === grid) { rows.push(tr); }
            });
        });
        return rows;
    }

    /* ------------------------ placement ---------------------------------
     * Numeric cellIndex arithmetic drifts as soon as our own cell is in
     * the row, or a row has a different number of cells from the header.
     * When it drifts, a stock cell ends up under our header - which is
     * exactly the "raw Constraints text under Role Entitlements" symptom.
     *
     * Instead we mirror an anchor: our cell always goes before the Nth
     * STOCK cell (ignoring our own), where N is the same number used in
     * the header. Counting only stock cells makes this stable no matter
     * how often the sweep runs.
     * ------------------------------------------------------------------ */

    /* Number of stock cells that precede our cell in the header. */
    function stockCellsBefore(row, node) {
        var n = 0;
        for (var i = 0; i < row.cells.length; i++) {
            if (row.cells[i] === node) { return n; }
            if (!row.cells[i].classList.contains(COL)) { n++; }
        }
        return n;
    }

    /* Insert `node` into `row` so that exactly `n` stock cells precede it. */
    function placeMirrored(row, node, n) {
        var seen = 0, ref = null;
        for (var i = 0; i < row.cells.length; i++) {
            var c = row.cells[i];
            if (c === node) { continue; }
            if (seen === n) { ref = c; break; }
            if (!c.classList.contains(COL)) { seen++; }
        }
        if (node.parentNode === row && node.nextElementSibling === ref) {
            return;                       /* already in the right place */
        }
        row.insertBefore(node, ref);
    }

    /* The row's constraint text. Uses the header index, but falls back to
       scanning the row when that cell holds nothing bracket-like - so a
       row with an unexpected shape still renders instead of showing raw
       text or nothing. */
    function constraintText(tr, cIdx) {
        var cell = (cIdx > -1) ? stockCellAt(tr, cIdx) : null;
        if (cell) {
            var t = cell.textContent || '';
            if (t.indexOf('[') > -1) { return t; }
        }
        /* fallback: a row with an unexpected shape still renders */
        for (var i = 0; i < tr.cells.length; i++) {
            var c = tr.cells[i];
            if (c.classList.contains(COL)) { continue; }
            var s2 = c.textContent || '';
            if (s2.indexOf('[') > -1 && /contains|equals|\+/i.test(s2)) {
                return s2;
            }
        }
        return cell ? (cell.textContent || '') : '';
    }

    /* A "Role: X" group header row spans the grid. It gets no cell of its
       own - adding one would push the real columns out of alignment.
       It is otherwise left completely alone. */
    function isGroupRow(tr) {
        for (var i = 0; i < tr.cells.length; i++) {
            if (tr.cells[i].colSpan > 1) { return true; }
        }
        return false;
    }

    /* ---------------------------- parse ---------------------------------- */

    /* Pull the entitlements out of a constraint string.
     *
     * Two real formats, both from live role composition reviews:
     *
     *   Contains All Of [AcctsPayableAccess, AcctsPayableAccess1,
     *                    AcctsReceivableAccess]
     *     -> three separate entitlements, split on commas.
     *
     *   Group Membership Contains All Of [CN=Dev Group Admin,OU=DEV
     *                    USERS,DC=seri,DC=sailpointdemo,DC=com]
     *     -> ONE entitlement: an LDAP distinguished name that happens to
     *        contain commas. Splitting it would produce four meaningless
     *        fragments, so DN components are kept together.
     *
     * The rule: split on commas, then re-join any piece that begins with
     * an LDAP attribute prefix (CN=, OU=, DC=, O=, UID=, ...) onto the
     * previous piece, since it is a continuation of the same DN.
     *
     * If there are no brackets the whole string is shown as one line
     * rather than nothing, so no data is ever silently dropped.
     */
    var DN_PART = /^(cn|ou|dc|o|l|st|c|uid|dn|sn|email|mail)\s*=/i;

    function splitList(inner) {
        var parts = inner.split(','), out = [];
        parts.forEach(function (raw) {
            var v = raw.trim();
            if (!v) { return; }
            if (out.length && DN_PART.test(v) && DN_PART.test(out[out.length - 1])) {
                out[out.length - 1] += ',' + v;   /* same DN, keep together */
            } else {
                out.push(v);
            }
        });
        return out;
    }

    function parseConstraints(text) {
        if (!text) { return []; }
        var out = [], re = /\[([^\]]*)\]/g, m;
        while ((m = re.exec(text)) !== null) {
            splitList(m[1].replace(/\s+/g, ' ')).forEach(function (v) {
                out.push(v);
            });
        }
        if (!out.length) {
            var t = text.replace(/\s+/g, ' ').trim();
            if (t) { out.push(t); }
        }
        return out;
    }

    /* ---------------------------- row state ------------------------------
     * The grid repaints rows on sort / page / filter and when a decision is
     * made, which throws away our cell and anything drawn in it. Choices
     * are therefore kept here, keyed by role + constraint text, and drawn
     * back onto whatever row currently shows that profile.
     * --------------------------------------------------------------------- */

    var rowState = {};

    function stateFor(key) {
        if (!rowState[key]) {
            rowState[key] = { choices: {}, auto: null, savedNote: null, stale: false, busyUntil: 0 };
        }
        return rowState[key];
    }

    /* Role name from the nearest "Role: X" group row above. */
    function roleOf(tr) {
        var p = tr.previousElementSibling;
        while (p) {
            if (isGroupRow(p)) {
                return (p.textContent || '').replace(/\s+/g, ' ').trim();
            }
            p = p.previousElementSibling;
        }
        return '';
    }

    function keyOf(tr, text) {
        return roleOf(tr) + '||' + (text || '').replace(/\s+/g, ' ').trim();
    }

    function removalCount(st) {
        var n = 0;
        Object.keys(st.choices).forEach(function (k) {
            if (st.choices[k] === 'revoke') { n++; }
        });
        return n;
    }

    /* ---------------------------- render --------------------------------- */

    function buildHeaderCell() {
        var th = document.createElement('th');
        th.className = COL;
        th.textContent = COLUMN_TITLE;
        return th;
    }

    function renderCell(td, ents, st) {
        while (td.firstChild) { td.removeChild(td.firstChild); }
        if (!ents.length) { return; }          /* blank cell, no filler text */

        /* Already-split row: one entitlement, already readable in
           Constraints. Nothing useful to add, so add nothing. */
        if (SKIP_SINGLE && ents.length === 1) { return; }

        var limit = (VISIBLE_LINES > 0) ? VISIBLE_LINES : ents.length;

        var wrap = document.createElement('div');
        wrap.className = 'rce-lines';
        ents.forEach(function (e, i) {
            var line = document.createElement('div');
            line.className = 'rce-line' + (i >= limit ? ' rce-hide' : '');

            if (MARK_MODE) {
                var box = document.createElement('input');
                box.type = 'checkbox';
                box.className = 'rce-mark';
                box.setAttribute('aria-label', 'Mark for removal: ' + e);
                line.appendChild(box);
            }

            var txt = document.createElement('span');
            txt.className = 'rce-text';
            txt.textContent = e;
            line.appendChild(txt);

            if (ENT_BUTTONS) {
                line.appendChild(buildEntButtons(e));
            }

            wrap.appendChild(line);
            if (st) { paintChoice(line, st.choices[e] || null); }
        });
        td.appendChild(wrap);

        if (ents.length > limit) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'rce-toggle';
            btn.textContent = 'Show ' + (ents.length - limit) + ' more';
            td.appendChild(btn);
        }

        if (MARK_MODE) {
            var foot = document.createElement('div');
            foot.className = 'rce-foot';

            var note = document.createElement('button');
            note.type = 'button';
            note.className = 'rce-note';
            note.textContent = 'Copy note';
            foot.appendChild(note);

            var hint = document.createElement('span');
            hint.className = 'rce-hint';
            hint.textContent = 'ticks build a note, not a decision';
            foot.appendChild(hint);

            td.appendChild(foot);
            updateFoot(td);
        }

        if (WARNING_TEXT) { updateWarning(td); }
    }

    /* Colour the entitlement AND fill the button that was pressed, so the
       reviewer can see which one is selected, not only the text colour. */
    function paintChoice(line, choice) {
        line.classList.remove('rce-chose-approve', 'rce-chose-revoke');
        if (choice) { line.classList.add('rce-chose-' + choice); }
        toArray(line.querySelectorAll('.rce-act')).forEach(function (b) {
            var mine = b.classList.contains('rce-act-' + choice);
            b.classList.toggle('rce-act-on', !!choice && mine);
            b.setAttribute('aria-pressed', (!!choice && mine) ? 'true' : 'false');
        });
    }

    /* Show the footer only once something is marked. */
    function updateFoot(td) {
        var foot = td.querySelector('.rce-foot');
        if (!foot) { return; }
        var marked = td.querySelectorAll('.rce-mark:checked').length;
        foot.style.display = marked ? '' : 'none';
        var btn = foot.querySelector('.rce-note');
        if (btn && btn.getAttribute('data-copied') !== '1') {
            btn.textContent = 'Copy note (' + marked + ')';
        }
    }

    /* Build the note for one row. Only entitlements the reviewer actually
       marked are listed, so nothing untouched is reported either way. */
    function noteTextFor(td) {
        var remove = [], keep = [];

        toArray(td.querySelectorAll('.rce-line')).forEach(function (line) {
            var txt = line.querySelector('.rce-text');
            if (!txt) { return; }
            var name = txt.textContent;
            var box = line.querySelector('.rce-mark');

            if (line.classList.contains('rce-chose-revoke')
                || (box && box.checked)) {
                remove.push(name);
            } else if (line.classList.contains('rce-chose-approve')) {
                keep.push(name);
            }
        });

        if (!remove.length && !keep.length) { return ''; }

        var parts = [];
        if (remove.length) { parts.push('Remove: ' + remove.join('; ')); }
        if (keep.length) { parts.push('Keep: ' + keep.join('; ')); }

        return NOTE_PREFIX + parts.join(' | ');
    }

    /* True when at least one entitlement on this row is marked for removal. */
    function hasRemoval(td) {
        return !!(td.querySelector('.rce-chose-revoke')
               || td.querySelector('.rce-mark:checked'));
    }

    /* With AUTO_ROW_DECISION on, the row is revoked for the reviewer, so
       the amber box is only needed when the plugin could not do it. */
    function updateWarning(td) {
        var warn = td.querySelector('.rce-warn');
        var tr = td.closest('tr');
        var st = tr ? rowState[td.getAttribute('data-key')] : null;
        var handled = AUTO_ROW_DECISION && st && st.auto === 'revoke';

        if (!hasRemoval(td) || handled) {
            if (warn) { warn.parentNode.removeChild(warn); }
            return;
        }
        if (warn) { return; }

        warn = document.createElement('div');
        warn.className = 'rce-warn';
        warn.textContent = WARNING_TEXT;
        td.appendChild(warn);
    }

    function onCopyNote(btn) {
        var td = btn.closest('td.' + COL);
        if (!td) { return; }
        var text = noteTextFor(td);
        var done = function () {
            btn.setAttribute('data-copied', '1');
            btn.textContent = 'Copied - paste into Comments';
            setTimeout(function () {
                btn.removeAttribute('data-copied');
                updateFoot(td);
            }, 4000);
        };
        if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(done, function () {
                fallbackCopy(text, done);
            });
        } else {
            fallbackCopy(text, done);
        }
    }

    function fallbackCopy(text, done) {
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand('copy'); } catch (e) { /* ignore */ }
        document.body.removeChild(ta);
        done();
    }

    /* Approve / Revoke pair for one entitlement line. */
    function buildEntButtons(name) {
        var box = document.createElement('span');
        box.className = 'rce-acts';

        ['Approve', 'Revoke'].forEach(function (label) {
            var b = document.createElement('button');
            b.type = 'button';
            b.className = 'rce-act rce-act-' + label.toLowerCase();
            b.textContent = label;
            b.setAttribute('aria-pressed', 'false');
            b.setAttribute('aria-label', label + ' ' + name);
            b.title = AUTO_ROW_DECISION && label === 'Revoke'
                ? 'Marks this entitlement for removal and revokes the row.'
                : 'Marks this entitlement in the comment sent to the role owner.';
            box.appendChild(b);
        });

        return box;
    }

    function onEntAct(btn) {
        var line = btn.closest('.rce-line');
        var td = btn.closest('td.' + COL);
        if (!line || !td) { return; }

        var chose = btn.classList.contains('rce-act-approve') ? 'approve' : 'revoke';
        var name = line.querySelector('.rce-text').textContent;
        var key = td.getAttribute('data-key');
        var st = stateFor(key);

        st.choices[name] = chose;
        paintChoice(line, chose);

        if (AUTO_ROW_DECISION) { reconcile(key); }
        if (WARNING_TEXT) { updateWarning(td); }
        syncDecisionNote(key);
    }

    function onToggle(btn) {
        var wrap = btn.parentNode.querySelector('.rce-lines');
        if (!wrap) { return; }
        var expand = !!wrap.querySelector('.rce-hide');
        var limit = (VISIBLE_LINES > 0) ? VISIBLE_LINES : wrap.children.length;
        toArray(wrap.children).forEach(function (line, i) {
            line.classList.toggle('rce-hide', !expand && i >= limit);
        });
        btn.textContent = expand
            ? 'Show less'
            : 'Show ' + (wrap.children.length - limit) + ' more';
    }

    /* ------------------ the row's own IdentityIQ decision ------------------ */

    /* Current row for a key, since the grid may have repainted it. */
    function rowFor(key) {
        var td = document.querySelector('td.' + COL + '[data-key="' + cssEscape(key) + '"]');
        return td ? td.closest('tr') : null;
    }

    function cssEscape(s) {
        return String(s).replace(/(["\\])/g, '\\$1');
    }

    function decisionCell(tr) {
        var grid = tr.closest('table');
        var hr = grid && headerRow(grid);
        var idx = hr ? headerIndex(hr, DECISION_HEADER) : -1;
        return idx > -1 ? stockCellAt(tr, idx) : null;
    }

    /* The stock Approve or Revoke button in a row. Our own buttons and
       anything inside our column are never matched. */
    function nativeButton(tr, label) {
        var cell = decisionCell(tr);
        var scope = cell || tr;
        var want = label.toLowerCase();
        var list = toArray(scope.querySelectorAll('button, a[role="button"], [role="button"]'));
        for (var i = 0; i < list.length; i++) {
            var b = list[i];
            if (b.closest('.' + COL) || b.classList.contains('rce-act')) { continue; }
            var t = (b.textContent || b.getAttribute('aria-label') || '')
                .replace(/\s+/g, ' ').trim().toLowerCase();
            if (t === want || t.indexOf(want) === 0) { return b; }
        }
        return null;
    }

    function looksPressed(b) {
        if (!b) { return null; }
        if (b.getAttribute('aria-pressed') === 'true') { return true; }
        if (b.getAttribute('aria-checked') === 'true') { return true; }
        if (PRESSED_CLASS.test(b.className || '')) { return true; }
        return false;
    }

    /* 'approve' | 'revoke' | 'none' | 'unknown'.
       'unknown' means neither button carries a state this plugin can read,
       so it falls back to remembering what it clicked itself. */
    function rowDecision(tr) {
        var a = nativeButton(tr, 'Approve'), r = nativeButton(tr, 'Revoke');
        if (!a && !r) { return 'unknown'; }
        if (looksPressed(r)) { return 'revoke'; }
        if (looksPressed(a)) { return 'approve'; }
        return seenPressedState ? 'none' : 'unknown';
    }

    /* Set once any row button on the page has shown a readable selected
       state. Until then, "no button looks pressed" cannot be trusted. */
    var seenPressedState = false;

    function notePressedState() {
        if (seenPressedState) { return; }
        toArray(document.querySelectorAll('td button, td [role="button"]')).some(function (b) {
            if (b.closest('.' + COL)) { return false; }
            if (looksPressed(b)) { seenPressedState = true; return true; }
            return false;
        });
    }

    /* What the plugin just asked IdentityIQ to do, so the comment dialog
       that follows can be matched to it. */
    var pending = null;

    function clickNative(key, label) {
        var tr = rowFor(key);
        var b = tr && nativeButton(tr, label);
        if (!b) { return false; }
        stateFor(key).busyUntil = Date.now() + 2500;
        pending = {
            type: label.toLowerCase(),
            key: key,
            note: label === 'Revoke' ? noteFor(key) : '',
            at: Date.now()
        };
        b.click();
        return true;
    }

    function noteFor(key) {
        var tr = rowFor(key);
        var td = tr && tr.querySelector('td.' + COL);
        return td ? noteTextFor(td) : '';
    }

    function reconcile(key) {
        var st = stateFor(key);
        var tr = rowFor(key);
        if (!tr) { return; }
        var removals = removalCount(st);
        var dec = rowDecision(tr);
        var note = noteFor(key);

        if (removals > 0) {
            if (st.auto === 'revoke') {
                if (note !== st.savedNote) { refreshRevoke(key, dec); }
                return;
            }
            if (dec === 'revoke') {
                /* revoked by hand: never overwrite the reviewer's comment */
                st.stale = true;
                return;
            }
            if (clickNative(key, 'Revoke')) {
                st.auto = 'revoke';
                st.savedNote = note;
                st.stale = false;
            }
            return;
        }

        /* no removals left: undo only a Revoke the plugin made */
        if (st.auto === 'revoke') {
            st.auto = null;
            st.savedNote = null;
            st.stale = false;
            if (dec !== 'approve') { clickNative(key, 'Approve'); }
        }
    }

    /* Marks changed after the automatic Revoke, so the saved comment is
       out of date. Undo the Revoke and make it again, which opens a fresh
       dialog with the new note. Only attempted when the row's selected
       state can be read; otherwise the reviewer is told to redo it. */
    function refreshRevoke(key, dec) {
        var st = stateFor(key);
        if (dec !== 'revoke') { st.stale = true; syncDecisionNote(key); return; }

        var tr = rowFor(key);
        var b = tr && nativeButton(tr, 'Revoke');
        if (!b) { st.stale = true; return; }
        st.busyUntil = Date.now() + 3000;            /* our own undo, not the reviewer's */
        b.click();                                   /* undo */

        setTimeout(function () {
            var tr2 = rowFor(key);
            if (tr2 && rowDecision(tr2) !== 'revoke' && clickNative(key, 'Revoke')) {
                st.savedNote = noteFor(key);
                st.stale = false;
            } else {
                st.stale = true;
            }
            syncDecisionNote(key);
        }, 500);
    }

    /* The small grey line under the row's decision buttons. */
    function syncDecisionNote(key) {
        var tr = rowFor(key);
        if (!tr) { return; }
        var cell = decisionCell(tr);
        if (!cell) { return; }
        var st = rowState[key];
        var existing = cell.querySelector('.rce-auto-note');

        var text = '';
        if (st && AUTO_ROW_DECISION) {
            var n = removalCount(st);
            if (st.stale && n > 0) {
                text = STALE_NOTE;
            } else if (st.auto === 'revoke' && n > 0) {
                text = (n === 1 ? AUTO_NOTE_ONE : AUTO_NOTE_MANY).replace('{n}', n);
            }
        }

        if (!text) {
            if (existing) { existing.parentNode.removeChild(existing); }
            return;
        }
        if (!existing) {
            existing = document.createElement('div');
            existing.className = 'rce-auto-note';
            existing.setAttribute('role', 'status');
            cell.appendChild(existing);
        }
        if (existing.textContent !== text) { existing.textContent = text; }
        existing.classList.toggle('rce-auto-note-stale', !!st.stale);
    }

    /* If the reviewer approves the row by hand after an automatic Revoke,
       their decision stands: the plugin forgets its Revoke rather than
       fighting them, and the amber warning comes back. */
    function checkManualOverride(key, tr) {
        var st = rowState[key];
        if (!st || st.auto !== 'revoke') { return; }
        if (st.busyUntil && Date.now() < st.busyUntil) { return; }
        var dec = rowDecision(tr);
        if (dec === 'approve' || dec === 'none') {
            st.auto = null;
            st.savedNote = null;
            st.stale = false;
        }
    }

    /* ------------------- filling the stock comment box -------------------- */

    var lastCell = null;

    function rememberRow(target) {
        if (!target || !target.closest) { return; }
        var tr = target.closest('tr');
        if (!tr) { return; }
        var td = tr.querySelector('td.' + COL);
        if (td) { lastCell = td; }
    }

    function setFieldValue(field, text) {
        field.value = text;
        ['input', 'change', 'keyup', 'blur'].forEach(function (name) {
            var ev;
            try {
                ev = new Event(name, { bubbles: true });
            } catch (e) {
                ev = document.createEvent('Event');
                ev.initEvent(name, true, true);
            }
            field.dispatchEvent(ev);
        });
    }

    function visible(el) {
        return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
    }

    function findCommentField() {
        var fields = toArray(document.querySelectorAll(
            'textarea, input[type="text"]'));
        for (var i = 0; i < fields.length; i++) {
            var f = fields[i];
            if (f.closest('td.' + COL)) { continue; }
            if (f.closest('table')) { continue; }        /* not a grid filter */
            if (f.getAttribute('data-rce-filled') === '1') { continue; }
            if (!visible(f)) { continue; }
            if ((f.value || '').trim().length) { continue; }
            if (f.readOnly || f.disabled) { continue; }
            return f;
        }
        return null;
    }

    function dialogOf(field) {
        return field.closest('[role="dialog"], .modal, .modal-dialog, .modal-content, .x-window');
    }

    /* The dialog's confirm button. Anything that cancels is skipped. */
    function saveButtonIn(dlg) {
        var list = toArray(dlg.querySelectorAll('button, input[type="button"], input[type="submit"]'));
        for (var i = 0; i < list.length; i++) {
            var b = list[i];
            var t = (b.textContent || b.value || '').replace(/\s+/g, ' ').trim().toLowerCase();
            if (/^(save|complete|ok|submit|done|revoke|confirm)$/.test(t)
                && !b.disabled && visible(b)) {
                return b;
            }
        }
        return null;
    }

    function tryAutofill() {
        if (!AUTOFILL_COMMENT) { return; }

        if (pending && Date.now() - pending.at > 10000) { pending = null; }

        /* An automatic Approve needs no comment, so it gets none. If the
           certification demands one anyway, the reviewer fills it. */
        if (pending && pending.type === 'approve') { return; }

        var text = pending ? pending.note : (lastCell ? noteTextFor(lastCell) : '');
        if (!text) { return; }
        var field = findCommentField();
        if (!field) { return; }

        field.setAttribute('data-rce-filled', '1');
        setFieldValue(field, text);

        if (pending && pending.type === 'revoke' && AUTO_SAVE_DIALOG) {
            var dlg = dialogOf(field);
            pending = null;
            if (!dlg) { return; }
            setTimeout(function () {
                var save = saveButtonIn(dlg);
                if (save) { save.click(); }
            }, 250);                    /* let Angular register the text */
        } else if (pending) {
            pending = null;
        }
    }

    /* ---------------------------- the sweep ------------------------------ */

    function sweep() {
        var grid = findGrid();
        if (!grid) { return; }
        var hr = headerRow(grid);
        if (!hr) { return; }

        var cIdx = headerIndex(hr, CONSTRAINTS_HEADER);
        if (cIdx === -1) { return; }

        if (headerIndex(hr, COLUMN_TITLE) !== -1) { return; }

        var ths = toArray(hr.querySelectorAll('th.' + COL));
        ths.slice(1).forEach(function (n) { n.parentNode.removeChild(n); });
        var th = ths[0] || buildHeaderCell();

        var anchor = headerIndex(hr, INSERT_BEFORE);
        if (anchor === -1) {
            anchor = stockCount(hr);
        }
        placeMirrored(hr, th, anchor);

        var n = stockCellsBefore(hr, th);
        cIdx = headerIndex(hr, CONSTRAINTS_HEADER);

        notePressedState();

        ownRows(grid).forEach(function (tr) {
            var mine = toArray(tr.cells).filter(function (c) {
                return c.classList.contains(COL);
            });

            if (isGroupRow(tr)) {
                mine.forEach(function (x) { x.parentNode.removeChild(x); });
                return;
            }

            mine.slice(1).forEach(function (x) { x.parentNode.removeChild(x); });
            var td = mine[0];
            if (!td) {
                td = document.createElement('td');
                td.className = COL;
            }

            var text = constraintText(tr, cIdx);

            placeMirrored(tr, td, n);

            var key = keyOf(tr, text);
            if (td.getAttribute('data-key') !== key) {
                td.setAttribute('data-key', key);
            }

            if (td.getAttribute('data-src') !== text) {
                td.setAttribute('data-src', text);
                renderCell(td, parseConstraints(text), rowState[key]);
            }

            if (AUTO_ROW_DECISION) {
                checkManualOverride(key, tr);
                if (WARNING_TEXT) { updateWarning(td); }
                syncDecisionNote(key);
            }
        });
    }

    /* ---------------------------- boot ----------------------------------- */

    document.addEventListener('click', function (e) {
        rememberRow(e.target);
    }, true);

    document.addEventListener('click', function (e) {
        if (!e.target || !e.target.closest) { return; }
        var t = e.target.closest('.rce-toggle');
        if (t) { onToggle(t); return; }
        var n = e.target.closest('.rce-note');
        if (n) { onCopyNote(n); return; }
        var a = e.target.closest('.rce-act');
        if (a) { onEntAct(a); return; }
    });

    document.addEventListener('change', function (e) {
        if (!e.target || !e.target.classList) { return; }
        if (!e.target.classList.contains('rce-mark')) { return; }
        var td = e.target.closest('td.' + COL);
        if (td) {
            updateFoot(td);
            if (WARNING_TEXT) { updateWarning(td); }
        }
    });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', sweep);
    } else {
        sweep();
    }

    if (window.MutationObserver) {
        var queued = false;
        new MutationObserver(function () {
            tryAutofill();
            if (queued) { return; }
            queued = true;
            setTimeout(function () { queued = false; sweep(); }, 150);
        }).observe(document.body, { childList: true, subtree: true });
    }
    setInterval(sweep, SWEEP_MS);

    /* Console helpers for tuning on a real page. */
    window.rceCol = {
        sweep: sweep,
        grid: findGrid,
        note: function () { return lastCell ? noteTextFor(lastCell) : null; },
        field: findCommentField,
        fill: tryAutofill,
        state: function () { return rowState; },
        /* Decision the plugin reads for the row last clicked, plus the
           HTML of its buttons - send this if auto revoke misbehaves. */
        decision: function () {
            var tr = lastCell && lastCell.closest('tr');
            if (!tr) { return 'click a row first'; }
            var a = nativeButton(tr, 'Approve'), r = nativeButton(tr, 'Revoke');
            return {
                decision: rowDecision(tr),
                approveButton: a ? a.outerHTML : null,
                revokeButton: r ? r.outerHTML : null
            };
        },
        remove: function () {
            toArray(document.querySelectorAll('.' + COL + ', .rce-auto-note')).forEach(function (n) {
                n.parentNode.removeChild(n);
            });
        },
        headers: function () {
            var g = findGrid(), hr = g && headerRow(g);
            return hr ? toArray(hr.cells).map(function (c) {
                return (c.textContent || '').trim();
            }) : null;
        }
    };

}(window, document));
