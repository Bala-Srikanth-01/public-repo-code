RoleCertEntColumn 4.2
=====================

WHAT IT DOES

Adds a "Role Entitlements" column to the role composition access review
grid, listing each entitlement in the profile on its own line, with an
Approve / Revoke button beside each one.

When you then click IdentityIQ's own Revoke on the row and its comment
dialog opens, the plugin fills the comment box with a note naming the
individual entitlements, for example:

  Per-entitlement review: Remove: Dev-Access | Keep: read-access

Only entitlements the reviewer marked appear. Anything left untouched is
not mentioned either way.

That comment travels through sign-off into the work item raised for the
role owner, so the owner is told exactly which entitlement to take out.


WORK ITEMS ARE RAISED ONLY BY REVOCATION

Approving a row raises no work item, so nothing reaches the role owner
and the note goes nowhere. If anything in the profile needs to change,
the reviewer must REVOKE the row - the comment then says which
entitlements to remove and which to keep.

The plugin shows a reminder in the column as soon as an entitlement is
marked for removal, so this is hard to get wrong by accident.


NEW IN 4.2 - THE ROW DECISION FOLLOWS THE ENTITLEMENTS

Reviewers could mark an entitlement for removal and then approve the row,
so nothing reached the role owner. 4.2 closes that gap:

  - Mark any entitlement Revoke: the plugin clicks the row's own Revoke.
    If IdentityIQ opens its comment dialog, the note is filled in and
    Save is pressed (AUTO_SAVE_DIALOG), so the comment cannot be skipped.
  - Mark more entitlements afterwards: the plugin undoes and redoes the
    Revoke so the saved comment matches the new marks.
  - Set every mark back to Approve: the row goes back to Approve with no
    comment, since no work item exists until sign-off.
  - A short grey line under the row's buttons says why it was revoked:
      Auto-revoked: 1 entitlement marked for removal
  - The pressed entitlement button stays filled (green / red).

Safety rules:
  - The plugin only reverses a Revoke it made itself. A row the reviewer
    revoked by hand, with their own comment, is never switched back or
    overwritten.
  - If the reviewer approves the row by hand afterwards, that decision
    stands and the amber warning returns.
  - If the plugin cannot read which row button is selected (different
    skin), it does not guess. It asks the reviewer to click Revoke again.
    Run rceCol.decision() in the console and send the output so the
    selected class can be added to PRESSED_CLASS.


STILL NOT CHANGED: THE WORK ITEM TITLE

The role owner's work item still reads as removing the profile. That text
is built on the server at sign-off; a browser plugin cannot change it.
The per-entitlement note is in the work item as the reviewer's comment.
Changing the title needs a message catalog override or a workflow/rule.


WHAT IT DOES NOT DO

The per-entitlement buttons do NOT record decisions. Only IdentityIQ
writes to its certification tables, and a UI plugin cannot. The row-level
Approve / Revoke is still the decision of record; the buttons only build
the wording of the comment.

Because the note is free text, it is guidance for the role owner, not
structured audit data. You cannot report on it.


BEFORE IT WILL WORK

The certification must be scheduled with "require comments" enabled for
revocation (and approval, if you want notes on approvals too). Without
that, IdentityIQ never opens a comment dialog and there is nothing to
fill.

The role itself is NOT modified. No profiles are split, so role detection
is unchanged - this is the difference from the rule-based approach.


SETTINGS

At the top of ui/js/snippets/entitlementsColumn.js:

  INSERT_BEFORE      which column to sit before        'decision'
  CONSTRAINTS_HEADER column parsed for entitlements    'constraints'
  COLUMN_TITLE       header text                       'Role Entitlements'
  ENT_BUTTONS        show per-entitlement buttons      true
  AUTOFILL_COMMENT   fill the comment dialog           true
  NOTE_PREFIX        text in front of the note
  WARNING_TEXT       reminder to revoke the row ('' = off)
  AUTO_ROW_DECISION  row Revoke/Approve follows marks  true
  AUTO_SAVE_DIALOG   press Save on the comment dialog  true
  AUTO_NOTE_ONE/MANY line under the decision buttons
  STALE_NOTE         shown if comment cannot refresh
  DECISION_HEADER    column with the row buttons       'decision'
  PRESSED_CLASS      classes that mean selected
  MARK_MODE          tick boxes + Copy note button     false
  SKIP_SINGLE        blank the column on split roles   false
  VISIBLE_LINES      lines before "Show more"          3


IF THE COMMENT BOX IS NOT FILLED

Open the browser console on the access review page:

  rceCol.note()    the note for the row last clicked
  rceCol.field()   the comment field it would fill, or null
  rceCol.fill()    force an attempt
  rceCol.decision() row decision as read by the plugin, plus the
                   HTML of the row's Approve / Revoke buttons
  rceCol.state()    marks remembered per row

If note() is null, no entitlement was marked on that row. If field() is
null, the dialog's box was not recognised - send the dialog's HTML and
the selector can be narrowed.


INSTALL

Global Settings - Plugins - upload the zip. Refresh the access review
page afterwards.
