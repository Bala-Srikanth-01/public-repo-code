RoleCertEntColumn v1.2
======================

Adds a "Role Entitlements" column to the role certification grid.
One entitlement per line, first three visible, Show more / Show less.
No Java, no jar, no database - installs straight from the IIQ UI.

WHAT v1.1 FIXES (duplicate rows / mixed font sizes)
---------------------------------------------------
v1.0 marked the whole table as "done" and re-injected on a timer. IIQ
certification grids repaint their tbody on sort / page / filter, so you got:
  - duplicate header cells and duplicate entitlement cells,
  - cells falling out of line with the header, so entitlement text landed
    under stock columns and inherited the stock (larger) grid font.
That is exactly the "some rows big font, some normal" symptom.

v1.1 changes three things:
  1. IDEMPOTENT SWEEP - every pass enforces exactly ONE header cell and
     exactly ONE entitlement cell per row (extras removed), always as the
     LAST cell so alignment holds. Nested layout tables are skipped.
  2. HARD FONT RESET - the CSS force-resets font-size/weight inside
     td.rce-col with !important, so nothing inherits grid styling.
  3. DELEGATED CLICKS - grids that repaint by re-serializing the DOM keep
     markup but drop listeners, leaving dead buttons. The Show more toggle
     is now handled by one document-level listener that survives repaints.
  Repaints are also detected by a MutationObserver, with the timer kept
  only as a safety net.

WHAT v1.2 ADDS (column visible without scrolling, one row per role)
-------------------------------------------------------------------
1. The Role Entitlements column is inserted BEFORE the Decision column
   (matched by header text, see DECISION_HEADER in the JS) instead of
   appended last, and its width is capped, so it is on screen without
   horizontal scrolling.
2. The bold "Role: X" band rows are stock IIQ group headers. With one
   item per role they just repeat the role name in a bigger font - the
   "duplicate rows" you saw. v1.2 hides them (HIDE_ROLE_BANDS = true in
   the JS; set false to keep them, or run rceCol.showBands(true) in the
   console to check live). Band rows never receive an entitlement cell.

CHECKBOXES ARE NOT PLUGIN WORK
------------------------------
Row checkboxes for bulk decisions are stock IIQ config: in the
certification definition's Additional Settings, enable Bulk Approve and
Bulk Revoke, then generate a NEW access review. The plugin does not and
should not fake these.

MODES
-----
LIVE   - plugin REST endpoint answers -> real entitlements.
SAMPLE - endpoint absent (no jar installed) -> hardcoded data. The column
         header shows an amber SAMPLE DATA badge so mock data can never be
         mistaken for real data. This zip ships SAMPLE-only.

INSTALL
-------
Global Settings -> Plugins -> New Plugin -> upload this zip -> Install.
Then open a role certification. If you had v1.0 installed, uninstall it
first (or bump: this manifest is version 1.1.0.0 with the same name, so
upgrading in place also works).

STILL VERIFY ON YOUR INSTANCE
-----------------------------
Top of ui/js/snippets/entitlementsColumn.js:
  GRID_SELECTOR   - defaults to table.certification-grid, with a fallback
                    to the largest table on the page. Run rceCol.gridDebug()
                    in the F12 console to find the real one.
  roleNameFromRow - reads data-role-name, else the first cell's first line.
Console helpers: rceCol.gridDebug(), rceCol.reset(), rceCol.mode(),
rceCol.sweep().

The snippet regex is ".*certification.*" - narrow it to your page's URL
before this goes anywhere shared.
