/*
 * RoleCertEntColumn v1.2
 *
 * Adds a "Role Entitlements" column to the role certification grid.
 * One entitlement per line, first three visible, Show more / Show less.
 *
 * v1.2 (matches the agreed layout)
 * --------------------------------
 *   - Column is inserted BEFORE the Decision column instead of appended
 *     last, so it is visible without horizontal scrolling.
 *   - The duplicated bold "Role: X" group band rows can be hidden
 *     (HIDE_ROLE_BANDS below). They are stock IIQ group headers; with one
 *     item per role they just repeat the role name in a bigger font.
 *   - Band rows never receive an entitlement cell (they span the full
 *     width; giving them one broke column alignment).
 *
 * v1.1 (kept)
 * -----------
 *   - IDEMPOTENT SWEEP: every pass enforces exactly ONE header cell and
 *     ONE cell per item row at the SAME column index, removing extras.
 *     Grid repaints on sort/page/filter are therefore harmless.
 *   - HARD FONT RESET in the CSS so nothing inherits stock grid sizing.
 *   - DELEGATED CLICKS so Show more survives DOM re-serialization.
 *
 * TWO MODES
 * ---------
 *   LIVE   - plugin REST endpoint answers with real entitlements.
 *   SAMPLE - endpoint absent: hardcoded data, amber badge in the header
 *            so mock data can never be mistaken for real data.
 *
 * VERIFY ON YOUR INSTANCE:  GRID_SELECTOR, roleNameFromRow, and
 * DECISION_HEADER below. rceCol.gridDebug() in the console helps.
 */
(function (window, document) {
    'use strict';

    var TAG = '[RCE]';

    /* ------------------------------------------------------------------ *
     *  CONFIG                                                            *
     * ------------------------------------------------------------------ */

    /* The certification grid table. Falls back to the largest table on
       the page that has a thead. */
    var GRID_SELECTOR = 'table.certification-grid, div.certification-grid table';

    /* Header text of the column our column is inserted BEFORE. Case
       insensitive. If not found, the column is appended last (old
       behaviour). */
    var DECISION_HEADER = 'decision';

    /* Hide the bold "Role: X" group band rows that repeat each role name.
       Set to false to keep them. */
    var HIDE_ROLE_BANDS = true;

    /* How to read the role name out of an item row. */
    function roleNameFromRow(tr) {
        var v = tr.getAttribute('data-role-name')
             || tr.getAttribute('data-rolename');
        if (v) { return v.trim(); }
        var cell = firstOwnCell(tr);
        if (!cell) { return ''; }
        var txt = (cell.textContent || '').trim();
        return txt.split('\n')[0].trim();
    }

    var REST_URL = SailPointRelative('plugin/rest/RoleCertEntColumn/entitlements/');

    var VISIBLE_LINES = 3;
    var SWEEP_MS      = 1200;

    /* ------------------------------------------------------------------ */

    var COL_CLASS  = 'rce-col';
    var CELL_CLASS = 'rce-cell';
    var BAND_CLASS = 'rce-band';
    var mode       = null;
    var cache      = {};
    var pending    = {};

    var SAMPLE = {
        '__default__': [
            'Active Directory : memberOf = CN=Finance-Users,OU=Groups,DC=corp',
            'Active Directory : memberOf = CN=GL-ReadWrite,OU=Groups,DC=corp',
            'SAP : role = Z_FI_AP_CLERK',
            'SAP : role = Z_FI_GL_DISPLAY',
            'Oracle EBS : responsibility = AP Inquiry'
        ]
    };

    function SailPointRelative(p) {
        var m = window.location.pathname.match(/^(\/[^/]+)\//);
        return (m ? m[1] : '') + '/' + p;
    }

    /* ---------------------- data loading ------------------------------ */

    function loadEntitlements(roleName, cb) {
        if (cache[roleName]) { cb(cache[roleName]); return; }
        if (pending[roleName]) { pending[roleName].push(cb); return; }
        pending[roleName] = [cb];

        function done(list) {
            cache[roleName] = list;
            var cbs = pending[roleName] || [];
            delete pending[roleName];
            cbs.forEach(function (f) { f(list); });
        }

        if (mode === 'SAMPLE') {
            done(SAMPLE[roleName] || SAMPLE.__default__);
            return;
        }

        var xhr = new XMLHttpRequest();
        xhr.open('GET', REST_URL + encodeURIComponent(roleName), true);
        xhr.setRequestHeader('Accept', 'application/json');
        xhr.onreadystatechange = function () {
            if (xhr.readyState !== 4) { return; }
            if (xhr.status === 200) {
                mode = 'LIVE';
                var list = [];
                try { list = JSON.parse(xhr.responseText) || []; }
                catch (e) { console.warn(TAG, 'bad JSON from endpoint', e); }
                done(list);
            } else {
                if (mode === null) {
                    mode = 'SAMPLE';
                    console.info(TAG, 'endpoint answered', xhr.status,
                                 '- running in SAMPLE mode');
                }
                done(SAMPLE[roleName] || SAMPLE.__default__);
                refreshHeaderBadges();
            }
        };
        try { xhr.send(); }
        catch (e) {
            mode = 'SAMPLE';
            done(SAMPLE[roleName] || SAMPLE.__default__);
        }
    }

    /* ---------------------- DOM helpers ------------------------------- */

    function toArray(nl) { return Array.prototype.slice.call(nl); }

    function findGrids() {
        var grids = toArray(document.querySelectorAll(GRID_SELECTOR));
        if (grids.length) { return grids; }
        var best = null, bestRows = 2;
        toArray(document.querySelectorAll('table')).forEach(function (t) {
            if (!t.tHead || !t.tBodies.length) { return; }
            if (t.closest('td, th')) { return; }
            var n = t.tBodies[0].rows.length;
            if (n > bestRows) { best = t; bestRows = n; }
        });
        return best ? [best] : [];
    }

    function ownRows(grid) {
        var rows = [];
        toArray(grid.tBodies).forEach(function (tb) {
            if (tb.parentNode !== grid) { return; }
            toArray(tb.rows).forEach(function (tr) {
                if (tr.closest('table') === grid) { rows.push(tr); }
            });
        });
        return rows;
    }

    function firstOwnCell(tr) {
        for (var i = 0; i < tr.cells.length; i++) {
            if (!tr.cells[i].classList.contains(COL_CLASS)) {
                return tr.cells[i];
            }
        }
        return null;
    }

    function headerRow(grid) {
        return (grid.tHead && grid.tHead.rows.length)
            ? grid.tHead.rows[grid.tHead.rows.length - 1]
            : null;
    }

    /* A group band: a row that spans the grid (any colspan > 1) or whose
       visible text starts with "Role:" while having fewer cells than the
       header. Those rows are stock group headers, not items. */
    function isBandRow(tr, headerCellCount) {
        for (var i = 0; i < tr.cells.length; i++) {
            if (tr.cells[i].colSpan > 1) { return true; }
        }
        var ownCells = tr.cells.length -
            toArray(tr.cells).filter(function (c) {
                return c.classList.contains(COL_CLASS);
            }).length;
        if (ownCells < headerCellCount - 1) {
            return true;
        }
        var txt = (tr.textContent || '').trim();
        return /^Role\s*:/i.test(txt) && ownCells <= 2;
    }

    /* ---------------------- rendering --------------------------------- */

    function buildHeaderCell() {
        var th = document.createElement('th');
        th.className = COL_CLASS;
        th.appendChild(document.createTextNode('Role Entitlements'));
        var badge = document.createElement('span');
        badge.className = 'rce-mock';
        badge.textContent = 'sample data';
        badge.style.display = (mode === 'SAMPLE') ? '' : 'none';
        th.appendChild(badge);
        return th;
    }

    function refreshHeaderBadges() {
        toArray(document.querySelectorAll('th.' + COL_CLASS + ' .rce-mock'))
            .forEach(function (b) {
                b.style.display = (mode === 'SAMPLE') ? '' : 'none';
            });
    }

    function renderCell(td, ents) {
        while (td.firstChild) { td.removeChild(td.firstChild); }

        if (!ents || !ents.length) {
            var none = document.createElement('span');
            none.className = 'rce-none';
            none.textContent = 'No entitlements defined';
            td.appendChild(none);
            return;
        }

        var wrap = document.createElement('div');
        wrap.className = 'rce-lines';
        ents.forEach(function (e, i) {
            var line = document.createElement('div');
            line.className = 'rce-line' +
                (i >= VISIBLE_LINES ? ' rce-line-hidden' : '');
            line.textContent = e;
            wrap.appendChild(line);
        });
        td.appendChild(wrap);

        if (ents.length > VISIBLE_LINES) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'rce-toggle';
            btn.textContent = 'Show ' + (ents.length - VISIBLE_LINES) + ' more';
            td.appendChild(btn);
            /* No listener here: clicks are handled by ONE delegated
               listener on the document (see boot), which survives grids
               that repaint by re-serializing the DOM. */
        }
    }

    function onToggleClick(btn) {
        var td   = btn.closest('td.' + COL_CLASS);
        var wrap = td ? td.querySelector('.rce-lines') : null;
        if (!wrap) { return; }
        var expand = !!wrap.querySelector('.rce-line-hidden');
        toArray(wrap.children).forEach(function (line, i) {
            line.classList.toggle('rce-line-hidden',
                                  !expand && i >= VISIBLE_LINES);
        });
        btn.textContent = expand
            ? 'Show less'
            : 'Show ' + (wrap.children.length - VISIBLE_LINES) + ' more';
    }

    /* ---------------------- the idempotent sweep ---------------------- */

    /* Where our column belongs in the header: just before the Decision
       column, or at the end if there is none. Returns the index our
       th/td should occupy AFTER insertion. */
    function targetHeaderIndex(hr) {
        var idx = -1;
        for (var i = 0; i < hr.cells.length; i++) {
            var c = hr.cells[i];
            if (c.classList.contains(COL_CLASS)) { continue; }
            var t = (c.textContent || '').trim().toLowerCase();
            if (t === DECISION_HEADER ||
                t.indexOf(DECISION_HEADER) === 0) {
                idx = i;
                break;
            }
        }
        if (idx === -1) {
            /* no Decision column: index of the last slot */
            return hr.cells.length -
                (hr.querySelector('th.' + COL_CLASS) ? 1 : 0);
        }
        /* if our th currently sits BEFORE the decision cell, the decision
           cell's index already accounts for us */
        var ourTh = hr.querySelector('th.' + COL_CLASS);
        if (ourTh && ourTh.cellIndex < idx) { return idx - 1; }
        return idx;
    }

    function placeAt(row, node, index) {
        var ref = row.cells[index] || null;
        if (ref === node) { return; }
        row.insertBefore(node, ref);
    }

    function sweep() {
        findGrids().forEach(function (grid) {

            var hr = headerRow(grid);
            if (!hr) { return; }

            /* HEADER: exactly one rce th, before the Decision column. */
            var ths = toArray(hr.querySelectorAll('th.' + COL_CLASS));
            ths.slice(1).forEach(function (n) { n.parentNode.removeChild(n); });
            var th = ths[0] || buildHeaderCell();
            var idx = targetHeaderIndex(hr);
            if (!th.parentNode || th.cellIndex !== idx) {
                placeAt(hr, th, idx);
            }
            idx = th.cellIndex;   /* authoritative index for the cells */
            var headerCellCount = hr.cells.length;

            /* ROWS */
            ownRows(grid).forEach(function (tr) {
                var cells = toArray(tr.cells).filter(function (c) {
                    return c.classList.contains(COL_CLASS);
                });

                /* group bands: never get a cell, optionally hidden */
                if (isBandRow(tr, headerCellCount)) {
                    cells.forEach(function (n) { n.parentNode.removeChild(n); });
                    tr.classList.add(BAND_CLASS);
                    tr.classList.toggle('rce-band-hidden', HIDE_ROLE_BANDS);
                    return;
                }
                tr.classList.remove(BAND_CLASS, 'rce-band-hidden');

                /* item rows: exactly one rce td, at the header's index */
                cells.slice(1).forEach(function (n) { n.parentNode.removeChild(n); });
                var td = cells[0];
                if (!td) {
                    td = document.createElement('td');
                    td.className = COL_CLASS + ' ' + CELL_CLASS;
                }
                if (!td.parentNode || td.cellIndex !== idx) {
                    placeAt(tr, td, Math.min(idx, tr.cells.length));
                }

                if (td.getAttribute('data-rce-filled')) { return; }
                td.setAttribute('data-rce-filled', '1');

                var role = roleNameFromRow(tr);
                if (!role) { renderCell(td, []); return; }

                td.textContent = 'Loading\u2026';
                td.className = COL_CLASS + ' ' + CELL_CLASS;
                loadEntitlements(role, function (ents) {
                    if (!td.isConnected) { return; }
                    renderCell(td, ents);
                });
            });
        });
    }

    /* ---------------------- console helpers --------------------------- */

    window.rceCol = {
        gridDebug: function () {
            var tables = document.querySelectorAll('table');
            console.log(TAG, tables.length + ' table(s) on this page');
            tables.forEach(function (t, i) {
                var heads = [];
                t.querySelectorAll('thead th, thead td').forEach(function (h) {
                    heads.push((h.textContent || '').trim());
                });
                console.log('  #' + i + ' rows=' +
                    (t.tBodies.length ? t.tBodies[0].rows.length : 0) +
                    ' class="' + (t.className || '') + '" headers=', heads, t);
            });
        },
        reset: function () {
            toArray(document.querySelectorAll('.' + COL_CLASS)).forEach(function (n) {
                n.parentNode.removeChild(n);
            });
            toArray(document.querySelectorAll('.' + BAND_CLASS)).forEach(function (n) {
                n.classList.remove(BAND_CLASS, 'rce-band-hidden');
            });
            cache = {};
            sweep();
        },
        showBands: function (show) {
            HIDE_ROLE_BANDS = !show;
            sweep();
            toArray(document.querySelectorAll('.' + BAND_CLASS))
                .forEach(function (tr) {
                    tr.classList.toggle('rce-band-hidden', HIDE_ROLE_BANDS);
                });
        },
        mode: function () { return mode; },
        sweep: sweep
    };

    /* ---------------------- boot -------------------------------------- */

    document.addEventListener('click', function (e) {
        var btn = e.target && e.target.closest
                ? e.target.closest('.rce-toggle') : null;
        if (btn) { onToggleClick(btn); }
    });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', sweep);
    } else {
        sweep();
    }

    if (window.MutationObserver) {
        var scheduled = false;
        new MutationObserver(function () {
            if (scheduled) { return; }
            scheduled = true;
            setTimeout(function () { scheduled = false; sweep(); }, 150);
        }).observe(document.body, { childList: true, subtree: true });
    }
    setInterval(sweep, SWEEP_MS);

}(window, document));
