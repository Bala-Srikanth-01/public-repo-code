package com.example.rolesplit;

import sailpoint.rest.plugin.BasePluginResource;
import sailpoint.rest.plugin.RequiredRight;
import sailpoint.tools.GeneralException;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * REST endpoints for the Role Profile Splitter plugin.
 *
 * Two endpoints:
 *   POST plugin/rest/RoleProfileSplitter/preview  - report only, saves nothing
 *   POST plugin/rest/RoleProfileSplitter/split    - makes the changes
 *
 * The right named below must exist in IdentityIQ and be granted to
 * whoever is allowed to reshape roles. Without it the endpoint refuses
 * the call - this is the one real advantage the plugin has over the
 * rule, which runs with whatever rights the task runner happens to have.
 */
@Path("RoleProfileSplitter")
@RequiredRight("RoleProfileSplitterRight")
public class SplitProfilesResource extends BasePluginResource {

    @Override
    public String getPluginName() {
        return "RoleProfileSplitter";
    }

    @POST
    @Path("preview")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Map<String, Object> preview(Map<String, Object> options)
            throws GeneralException {
        return execute(options, true);
    }

    @POST
    @Path("split")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Map<String, Object> split(Map<String, Object> options)
            throws GeneralException {
        return execute(options, false);
    }

    /**
     * Shared by both endpoints. testMode is decided here rather than by
     * the caller, so a mistyped request can never turn a preview into a
     * real change.
     */
    private Map<String, Object> execute(Map<String, Object> options,
                                        boolean testMode)
            throws GeneralException {

        ProfileSplitter splitter = new ProfileSplitter(getContext());

        splitter.setTestMode(testMode);
        splitter.setOnlyRole(stringValue(options, "onlyRole", null));
        splitter.setMaxRoles(intValue(options, "maxRoles", 1));
        splitter.setSetDescription(boolValue(options, "setDescription", true));
        splitter.setPreserveOperation(boolValue(options, "preserveOperation", true));

        List<String> report = splitter.run();

        Map<String, Object> result = new HashMap<String, Object>();
        result.put("testMode", testMode);
        result.put("rolesChanged", splitter.getRolesChanged());
        result.put("profilesCreated", splitter.getProfilesCreated());
        result.put("profilesRemoved", splitter.getProfilesRemoved());
        result.put("report", report);
        return result;
    }

    /* ---- small helpers so a missing or odd value cannot break the call ---- */

    private String stringValue(Map<String, Object> map, String key, String fallback) {
        if (map == null) { return fallback; }
        Object v = map.get(key);
        if (v == null) { return fallback; }
        String s = String.valueOf(v).trim();
        return (s.length() == 0) ? fallback : s;
    }

    private int intValue(Map<String, Object> map, String key, int fallback) {
        if (map == null) { return fallback; }
        Object v = map.get(key);
        if (v instanceof Number) { return ((Number) v).intValue(); }
        try {
            return Integer.parseInt(String.valueOf(v));
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private boolean boolValue(Map<String, Object> map, String key, boolean fallback) {
        if (map == null) { return fallback; }
        Object v = map.get(key);
        if (v instanceof Boolean) { return ((Boolean) v).booleanValue(); }
        if (v == null) { return fallback; }
        return Boolean.parseBoolean(String.valueOf(v));
    }
}
