package com.example.rolesplit;

import sailpoint.api.SailPointContext;
import sailpoint.object.Application;
import sailpoint.object.Bundle;
import sailpoint.object.Filter;
import sailpoint.object.Profile;
import sailpoint.object.QueryOptions;
import sailpoint.tools.GeneralException;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * Splits role profiles so each profile holds one entitlement.
 *
 * This is the same logic as the "Split Entitlement Profiles" rule.
 * The difference is packaging: the rule is text that IdentityIQ
 * interprets, this is compiled Java the plugin calls.
 */
public class ProfileSplitter {

    private final SailPointContext context;

    /** true = work out the changes but save nothing. */
    private boolean testMode = true;

    /** One role name, or null for every role. */
    private String onlyRole = null;

    /** Stop after this many roles have been changed. */
    private int maxRoles = 1;

    /** Fills the certification's Profile Description column. */
    private boolean setDescription = true;

    /** Keep "contains all of" wording rather than switching to "=". */
    private boolean preserveOperation = true;

    /* counters, readable after run() */
    private int rolesChanged = 0;
    private int profilesCreated = 0;
    private int profilesRemoved = 0;

    private final List<String> report = new ArrayList<String>();

    public ProfileSplitter(SailPointContext context) {
        this.context = context;
    }

    public void setTestMode(boolean v)       { this.testMode = v; }
    public void setOnlyRole(String v)        { this.onlyRole = v; }
    public void setMaxRoles(int v)           { this.maxRoles = v; }
    public void setSetDescription(boolean v) { this.setDescription = v; }
    public void setPreserveOperation(boolean v) { this.preserveOperation = v; }

    public int getRolesChanged()    { return rolesChanged; }
    public int getProfilesCreated() { return profilesCreated; }
    public int getProfilesRemoved() { return profilesRemoved; }
    public List<String> getReport() { return report; }

    /**
     * Runs the split. Returns the report lines.
     */
    public List<String> run() throws GeneralException {

        List<String> roleIds = findRoleIds();
        report.add("Roles examined: " + roleIds.size());
        report.add("");

        for (String roleId : roleIds) {

            if (rolesChanged >= maxRoles) {
                report.add("STOPPED: reached MAX_ROLES limit of " + maxRoles);
                break;
            }

            Bundle role = context.getObjectById(Bundle.class, roleId);
            if (role == null) {
                continue;
            }

            try {
                processRole(role);
            } finally {
                context.decache(role);   /* release before the next role */
            }
        }

        return report;
    }

    /** Collect IDs only, so we never hold every role in memory at once. */
    private List<String> findRoleIds() throws GeneralException {

        QueryOptions query = new QueryOptions();
        if (onlyRole != null && onlyRole.length() > 0) {
            query.addFilter(Filter.eq("name", onlyRole));
        }

        List<String> ids = new ArrayList<String>();
        Iterator<Object[]> results = context.search(Bundle.class, query, "id");
        while (results.hasNext()) {
            ids.add((String) results.next()[0]);
        }
        return ids;
    }

    private void processRole(Bundle role) throws GeneralException {

        List<Profile> profiles = role.getProfiles();
        if (profiles == null || profiles.isEmpty()) {
            return;
        }

        /* Cannot edit the list while looping it, so collect changes first. */
        List<Profile> toAdd = new ArrayList<Profile>();
        List<Profile> toRemove = new ArrayList<Profile>();

        for (Profile profile : profiles) {

            /* Skip: permissions could change meaning if split. */
            if (profile.getPermissions() != null
                    && !profile.getPermissions().isEmpty()) {
                report.add("  SKIPPED (has permissions): " + role.getName());
                continue;
            }

            List<Filter> rules = profile.getConstraints();

            /* Skip: several rules are joined by AND/OR - leave for a human. */
            if (rules == null || rules.size() != 1) {
                if (rules != null && rules.size() > 1) {
                    report.add("  SKIPPED (" + rules.size() + " rules): "
                               + role.getName());
                }
                continue;
            }

            List<Object> values = getValuesToSplit(rules.get(0));
            if (values == null) {
                continue;                     /* already one per profile */
            }

            Filter.LeafFilter simpleRule = (Filter.LeafFilter) rules.get(0);
            String appName = applicationName(profile);

            report.add("  Role '" + role.getName() + "': profile on " + appName
                       + " holds " + values.size() + " entitlements ->");

            for (Object oneValue : values) {
                toAdd.add(buildProfile(profile, simpleRule, oneValue, appName));
                report.add("      + " + String.valueOf(oneValue));
            }

            toRemove.add(profile);            /* the original is replaced */
        }

        applyChanges(role, toAdd, toRemove);
    }

    /** One new profile holding exactly one entitlement. */
    private Profile buildProfile(Profile original,
                                 Filter.LeafFilter simpleRule,
                                 Object oneValue,
                                 String appName) {

        Profile newProfile = new Profile();
        newProfile.setApplication(original.getApplication());

        if (setDescription) {
            newProfile.setDescription(appName + " - " + String.valueOf(oneValue));
        }

        List<Filter> newRules = new ArrayList<Filter>();
        newRules.add(buildSingleValueRule(simpleRule, oneValue));
        newProfile.setConstraints(newRules);

        return newProfile;
    }

    private void applyChanges(Bundle role,
                              List<Profile> toAdd,
                              List<Profile> toRemove) throws GeneralException {

        if (toAdd.isEmpty()) {
            return;
        }

        if (testMode) {
            report.add("    TEST MODE - nothing saved");
        } else {
            for (Profile p : toRemove) {
                role.remove(p);
            }
            for (Profile p : toAdd) {
                role.add(p);
            }
            context.saveObject(role);         /* stage the change  */
            context.commitTransaction();      /* write it to the DB */
            report.add("    SAVED");
        }

        rolesChanged++;
        profilesCreated += toAdd.size();
        profilesRemoved += toRemove.size();
    }

    /** Builds the rule for a new profile: same attribute, one value. */
    private Filter buildSingleValueRule(Filter.LeafFilter originalRule,
                                        Object oneValue) {
        if (preserveOperation) {
            try {
                return Filter.containsAll(originalRule.getProperty(),
                                          Collections.singletonList(oneValue));
            } catch (Throwable t) {
                /* method missing in this version - fall through to equals */
            }
        }
        return Filter.eq(originalRule.getProperty(), oneValue);
    }

    /** Returns the entitlement values if there are 2 or more, else null. */
    private List<Object> getValuesToSplit(Filter profileRule) {

        if (!(profileRule instanceof Filter.LeafFilter)) {
            return null;                      /* AND/OR rule */
        }

        Object value = ((Filter.LeafFilter) profileRule).getValue();
        if (!(value instanceof Collection)) {
            return null;                      /* single value */
        }

        List<Object> values = new ArrayList<Object>((Collection<?>) value);
        if (values.size() < 2) {
            return null;                      /* nothing to split */
        }
        return values;
    }

    private String applicationName(Profile profile) {
        Application app = profile.getApplication();
        return (app != null) ? app.getName() : "unknown application";
    }
}
