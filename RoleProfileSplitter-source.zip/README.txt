ROLE PROFILE SPLITTER - PLUGIN VERSION
=====================================

Same job as the "Split Entitlement Profiles" rule: it splits role profiles
so each holds one entitlement, which makes a Role Composition
certification show one row - and one Approve/Revoke - per entitlement.

This exists so you can compare the two approaches.


WHAT IS IN HERE
---------------
  manifest.xml                      plugin definition
  src/.../ProfileSplitter.java      the splitting logic (same as the rule)
  src/.../SplitProfilesResource.java  REST endpoints the UI calls
  ui/index.html                     the page with Preview / Apply buttons
  build.sh                          compiles the jar and zips the plugin

The Java compiles cleanly, but it was compiled against hand-written stubs
of the IdentityIQ API, NOT against identityiq.jar. So the syntax is sound
and the structure is right, but method names and signatures still need
checking against your version's javadoc. Expect to fix a few before it
builds for real.


TO BUILD
--------
  IIQ_LIB=/opt/tomcat/webapps/identityiq/WEB-INF/lib ./build.sh

Then upload RoleProfileSplitter.zip via Global Settings -> Plugins.
Create the SPRight "RoleProfileSplitterRight" and grant it to whoever is
allowed to reshape roles, or the endpoints will refuse every call.


PLUGIN VS RULE
--------------
                              Rule            Plugin
  Splits roles                yes             yes, same logic
  Per-entitlement decisions   from IIQ, after splitting (both)
  Needs Java / jar / build    no              yes
  Needs a JDK on someone's    no              yes
    machine to change it
  Can be scheduled            yes             not directly - the UI is
                                              manual; you would still
                                              write a task for schedules
  Runs as                     whoever runs    the logged-in user, gated
                                the task      by an SPRight
  Change it in Debug page     yes             no, rebuild and redeploy
  Non-technical users can     no              yes, it has a page
    run it themselves

THE HONEST SUMMARY
The plugin does not do anything the rule cannot. It packages the same
logic behind a page with buttons. It is worth building if:

  - people without task-runner access need to run this themselves, or
  - you want the SPRight check so only role admins can reshape roles, or
  - it has to look like a product feature rather than an admin script.

It is not worth building if an administrator running a scheduled task is
acceptable. The rule is one file, editable in the Debug page, with no
build pipeline and nothing to redeploy when a setting changes.

One thing the plugin genuinely adds: the preview and the apply are
separate endpoints, and the server decides which is which. A caller
cannot turn a preview into a real change by sending the wrong flag. In
the rule, that safety is a variable anyone can edit.


BEFORE USING EITHER ON REAL ROLES
---------------------------------
  1. Back up: export -c Bundle roles-backup.xml
  2. Preview first and read the report.
  3. After applying, run Identity Refresh and confirm role membership is
     unchanged. Splitting can change how IdentityIQ decides who matches a
     role - that is the one real risk, and it applies to both versions.
  4. Consider how many rows your certifications will gain. A role with
     five entitlements becomes five rows. Reviewers notice.
