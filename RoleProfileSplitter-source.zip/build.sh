#!/bin/bash
# Builds the plugin jar and zips the plugin.
#
# You need identityiq.jar from your IIQ install (WEB-INF/lib/identityiq.jar)
# and a JAX-RS api jar (also in WEB-INF/lib). Point IIQ_LIB at that folder.

set -e
IIQ_LIB="${IIQ_LIB:-/path/to/identityiq/WEB-INF/lib}"

if [ ! -d "$IIQ_LIB" ]; then
  echo "Set IIQ_LIB to your IdentityIQ WEB-INF/lib folder first:"
  echo "  IIQ_LIB=/opt/tomcat/webapps/identityiq/WEB-INF/lib ./build.sh"
  exit 1
fi

rm -rf build && mkdir -p build/classes lib

echo "Compiling..."
javac -source 8 -target 8 \
      -cp "$IIQ_LIB/*" \
      -d build/classes \
      $(find src -name '*.java')

echo "Building jar..."
jar cf lib/role-profile-splitter.jar -C build/classes .

echo "Zipping plugin..."
rm -f RoleProfileSplitter.zip
zip -r RoleProfileSplitter.zip manifest.xml lib ui -x '.*'

echo "Done: RoleProfileSplitter.zip"
