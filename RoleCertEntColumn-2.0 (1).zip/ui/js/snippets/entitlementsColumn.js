/*
 * RoleCertEntColumn v2.0
 *
 * ONE JOB: add a "Role Entitlements" column to the role composition
 * access review grid, with each entitlement on its own line.
 *
 * It does NOT touch anything else on the page. Checkboxes, Bulk
 * Decisions, the "Role: X" group rows, Approve/Revoke, paging - all
 * stock IdentityIQ, left exactly as they are.
 *
 * WHERE THE DATA COMES FROM
 * -------------------------
 * The row already carries it. A role composition access review shows the
 * entitlement profile in the Constraints column, as one dense line:
 *
 *   EntitlementValue Contains All Of [Administrators + PWCHFSSGFTP01,
 *   Administrators + pwgsdscs3308001, Domain Users + pwchfssgclp01]
 *
 * We parse that and print:
 *
 *   Administrators + PWCHFSSGFTP01
 *   Administrators + pwgsdscs3308001
 *   Domain Users + pwchfssgclp01
 *
 * Real data. No Java, no jar, no REST endpoint, no database.
 *
 * WHY THE SWEEP RUNS REPEATEDLY
 * -----------------------------
 * The grid repaints its rows on sort / page / filter. Rather than inject
 * once and hope, every pass enforces exactly ONE header cell and ONE cell
 * per row at the same column index, removing any extras. Running it twice
 * changes nothing, so repaints are harmless. This is what stops the
 * duplicate cells and mismatched fonts seen in earlier versions.
 */
(function (window, document) {
    'use strict';

    /* ------------------------------ CONFIG ------------------------------ */

    /* Column header text to insert BEFORE, so the new column is visible
       without scrolling past the wide Decision column. Case insensitive.
       Set to '' to append the column last instead. */
    var INSERT_BEFORE = 'decision';

    /* Column header holding the constraint string we parse. */
    var CONSTRAINTS_HEADER = 'constraints';

    /* Our column's header text. */
    var COLUMN_TITLE = 'Role Entitlements';

    /* Entitlement lines shown before "Show more". Set to 0 for no limit. */
    var VISIBLE_LINES = 3;

    /* Safety-net re-check interval, ms. The MutationObserver catches
       repaints much faster; this only covers anything it misses. */
    var SWEEP_MS = 1500;

    /* --------------------------------------------------------------------- */

    var COL = 'rce-col';

    function toArray(nl) { return Array.prototype.slice.call(nl); }

    /* ---------------------------- find the grid -------------------------- */

    /* The certification grid is the largest table on the page that has a
       thead and is not nested inside another cell. Deliberately structural
       rather than class-based: IIQ grid class names differ across versions
       and skins, and a wrong class name would mean no column at all. */
    function findGrid() {
        var best = null, bestRows = 0;
        toArray(document.querySelectorAll('table')).forEach(function (t) {
            if (!t.tHead || !t.tBodies.length) { return; }
            if (t.parentNode && t.parentNode.closest &&
                t.parentNode.closest('td, th')) { return; }
            var n = t.tBodies[0].rows.length;
            if (n > bestRows) { best = t; bestRows = n; }
        });
        return best;
    }

    function headerRow(grid) {
        return (grid.tHead && grid.tHead.rows.length)
            ? grid.tHead.rows[grid.tHead.rows.length - 1]
            : null;
    }

    /* Index of the header cell whose text starts with `title`. -1 if none.
       Skips our own cell. */
    function headerIndex(hr, title) {
        if (!title) { return -1; }
        var want = title.toLowerCase();
        for (var i = 0; i < hr.cells.length; i++) {
            var c = hr.cells[i];
            if (c.classList.contains(COL)) { continue; }
            var t = (c.textContent || '').trim().toLowerCase();
            if (t === want || t.indexOf(want) === 0) { return i; }
        }
        return -1;
    }

    /* Rows belonging to this grid only, never rows of a nested table. */
    function ownRows(grid) {
        var rows = [];
        toArray(grid.tBodies).forEach(function (tb) {
            if (tb.parentNode !== grid) { return; }
            toArray(tb.rows).forEach(function (tr) {
                if (tr.closest('table') === grid) { rows.push(tr); }
            });
        });
        return rows;
    }

    /* A "Role: X" group header row spans the grid. It gets no cell of its
       own - adding one would push the real columns out of alignment.
       It is otherwise left completely alone. */
    function isGroupRow(tr) {
        for (var i = 0; i < tr.cells.length; i++) {
            if (tr.cells[i].colSpan > 1) { return true; }
        }
        return false;
    }

    /* ---------------------------- parse ---------------------------------- */

    /* Pull the entitlements out of a constraint string. Everything inside
       square brackets, split on commas. If there are no brackets, the
       whole string is shown as a single line rather than nothing. */
    function parseConstraints(text) {
        if (!text) { return []; }
        var out = [], re = /\[([^\]]*)\]/g, m;
        while ((m = re.exec(text)) !== null) {
            m[1].split(',').forEach(function (part) {
                var v = part.trim();
                if (v) { out.push(v); }
            });
        }
        if (!out.length) {
            var t = text.replace(/\s+/g, ' ').trim();
            if (t) { out.push(t); }
        }
        return out;
    }

    /* ---------------------------- render --------------------------------- */

    function buildHeaderCell() {
        var th = document.createElement('th');
        th.className = COL;
        th.textContent = COLUMN_TITLE;
        return th;
    }

    function renderCell(td, ents) {
        while (td.firstChild) { td.removeChild(td.firstChild); }
        if (!ents.length) { return; }          /* blank cell, no filler text */

        var limit = (VISIBLE_LINES > 0) ? VISIBLE_LINES : ents.length;

        var wrap = document.createElement('div');
        wrap.className = 'rce-lines';
        ents.forEach(function (e, i) {
            var line = document.createElement('div');
            line.className = 'rce-line' + (i >= limit ? ' rce-hide' : '');
            line.textContent = e;
            wrap.appendChild(line);
        });
        td.appendChild(wrap);

        if (ents.length > limit) {
            var btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'rce-toggle';
            btn.textContent = 'Show ' + (ents.length - limit) + ' more';
            td.appendChild(btn);
            /* No listener here: one delegated listener on the document
               (see bottom) survives grids that repaint by re-serializing
               their HTML, which silently drops node listeners. */
        }
    }

    function onToggle(btn) {
        var wrap = btn.parentNode.querySelector('.rce-lines');
        if (!wrap) { return; }
        var expand = !!wrap.querySelector('.rce-hide');
        var limit = (VISIBLE_LINES > 0) ? VISIBLE_LINES : wrap.children.length;
        toArray(wrap.children).forEach(function (line, i) {
            line.classList.toggle('rce-hide', !expand && i >= limit);
        });
        btn.textContent = expand
            ? 'Show less'
            : 'Show ' + (wrap.children.length - limit) + ' more';
    }

    /* ---------------------------- the sweep ------------------------------ */

    function sweep() {
        var grid = findGrid();
        if (!grid) { return; }
        var hr = headerRow(grid);
        if (!hr) { return; }

        /* Only act on a grid that actually has a Constraints column,
           so other IIQ tables are never touched. */
        var cIdx = headerIndex(hr, CONSTRAINTS_HEADER);
        if (cIdx === -1) { return; }

        /* HEADER: exactly one of ours, at the wanted position. */
        var ths = toArray(hr.querySelectorAll('th.' + COL));
        ths.slice(1).forEach(function (n) { n.parentNode.removeChild(n); });
        var th = ths[0] || buildHeaderCell();

        var want = headerIndex(hr, INSERT_BEFORE);
        if (want === -1) { want = hr.cells.length; }
        if (th.parentNode && th.cellIndex < want) { want -= 1; }
        if (!th.parentNode || th.cellIndex !== want) {
            hr.insertBefore(th, hr.cells[want] || null);
        }
        var idx = th.cellIndex;

        /* re-read: inserting the header shifts Constraints if it sat after */
        cIdx = headerIndex(hr, CONSTRAINTS_HEADER);

        /* ROWS */
        ownRows(grid).forEach(function (tr) {
            var mine = toArray(tr.cells).filter(function (c) {
                return c.classList.contains(COL);
            });

            if (isGroupRow(tr)) {
                mine.forEach(function (n) { n.parentNode.removeChild(n); });
                return;
            }

            mine.slice(1).forEach(function (n) { n.parentNode.removeChild(n); });
            var td = mine[0];
            if (!td) {
                td = document.createElement('td');
                td.className = COL;
            }
            var at = Math.min(idx, tr.cells.length);
            if (!td.parentNode || td.cellIndex !== at) {
                tr.insertBefore(td, tr.cells[at] || null);
            }

            /* Re-render only when the source text changed, so expanded
               rows are not collapsed again by the next sweep. */
            var src = tr.cells[cIdx];
            var text = src ? (src.textContent || '') : '';
            if (td.getAttribute('data-src') === text) { return; }
            td.setAttribute('data-src', text);
            renderCell(td, parseConstraints(text));
        });
    }

    /* ---------------------------- boot ----------------------------------- */

    document.addEventListener('click', function (e) {
        var btn = e.target && e.target.closest
                ? e.target.closest('.rce-toggle') : null;
        if (btn) { onToggle(btn); }
    });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', sweep);
    } else {
        sweep();
    }

    if (window.MutationObserver) {
        var queued = false;
        new MutationObserver(function () {
            if (queued) { return; }
            queued = true;
            setTimeout(function () { queued = false; sweep(); }, 150);
        }).observe(document.body, { childList: true, subtree: true });
    }
    setInterval(sweep, SWEEP_MS);

    /* Console helpers for tuning on a real page. */
    window.rceCol = {
        sweep: sweep,
        grid: findGrid,
        remove: function () {
            toArray(document.querySelectorAll('.' + COL)).forEach(function (n) {
                n.parentNode.removeChild(n);
            });
        },
        headers: function () {
            var g = findGrid(), hr = g && headerRow(g);
            return hr ? toArray(hr.cells).map(function (c) {
                return (c.textContent || '').trim();
            }) : null;
        }
    };

}(window, document));
